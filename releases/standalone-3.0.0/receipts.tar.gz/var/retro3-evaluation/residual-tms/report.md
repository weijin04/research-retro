# Revealed residual recovery: isolated TMSN3 EA(Q)/DEA

Recovered 90 local isolated run directories: 78 wB97X-D4 single points, six DLPNO single points, and six r2SCAN optimization/scan jobs. All isolated single points terminate normally. The neutral scan itself fails at point 9; that geometry remains reference-only.

This is a revealed development audit, not blind acceptance. No scientific jobs, source modifications, frozen comparison changes or authoritative Retro state edits occurred.

## Recomputed energy comparisons

| Quantity | eV |
|---|---:|
| DLPNO_EA_vertical_eV | -0.398232546 |
| DLPNO_DEA_RNminus_plus_N2_minus_neutral_eV | 0.017609081 |
| DLPNO_neutral_triplet_products_minus_neutral_eV | 1.277301249 |
| DLPNO_RN_endpoint_EA_eV | 1.259692168 |
| DLPNO_crossing_anion_minus_neutral_min_eV | 0.547568349 |
| wB97X_TZVP_RN_endpoint_EA_eV | 1.280006398 |
| wB97X_TZVP_RN_singlet_minus_triplet_eV | 1.828595156 |
| wB97X_TZVPD_RN_endpoint_EA_eV | 1.369536549 |
| wB97X_TZVPD_RN_singlet_minus_triplet_eV | 1.825225123 |

EA uses E(neutral)-E(anion). DEA uses E(RN−)+E(N2)−E(RN3 neutral), referenced to a free electron at vacuum. RN endpoint EA uses different optimized endpoint geometries; it is not vertical. Values are electronic energies without ZPE/free energy.

## Complete local EA(Q) table

| Q / Å | neutral-path TZVP | neutral-path TZVPD | anion-path TZVP | anion-path TZVPD |
|---:|---:|---:|---:|---:|
| 1.24 | -1.863531 | -1.218288 | 1.318331 | 1.428436 |
| 1.34 | -1.383046 | -1.267874 | 1.788693 | 1.878269 |
| 1.44 | -0.989671 | -0.835613 | 2.088843 | 2.166801 |
| 1.54 | -0.687661 | -0.552754 | 2.246866 | 2.317714 |
| 1.64 | -0.373042 | -0.246568 | 2.320838 | 2.387754 |
| 1.74 | 0.184927 | 0.290847 | 2.389455 | 2.454477 |
| 1.84 | 0.728227 | 0.822071 | 2.501167 | 2.567011 |
| 1.94 | 0.804670 | 0.883663 | 2.646844 | 2.715114 |
| 2.04 (neutral unconverged) | -0.611391 | -0.473060 | 2.799818 | 2.871240 |

At the same nominal Q=1.24 Å the two optimized paths differ by more than 2 eV in EA. Other coordinates/electronic solutions matter: Q alone cannot identify the physical state. The positive anion-relaxed EA does not remove the entry cost from the neutral geometry.

## Argument and exact gaps

**object**: Isolated C3H9N3Si, 16 atoms; q0 singlet and q-1 doublet, vacuum. RN endpoints C3H9NSi 14 atoms; neutral triplet/singlet and anion doublet, plus separately computed singlet N2. No graphene/hole/Fe in these isolated objects.

**methods**: r2SCAN-3c constrained relaxed scan B 2 1=1.24..2.04 Angstrom, 9 points; wB97X-D4/def2-TZVP and def2-TZVPD RIJCOSX neutral/anion SP pairs on identical coordinates; TightPNO DLPNO-CCSD(T)/aug-cc-pVTZ with aug-cc-pVTZ/C endpoints.

**EA_definition**: EA(Q)=E_neutral(Q)-E_anion(Q), free electron vacuum reference. Positive values mean the computed anion is lower than the specified neutral at identical Q and all remaining coordinates. Not direct interface-injection energy.

**path_distinction**: Anion-relaxed pt1 at 1.24 A already has EA 1.3183305/1.4284358 eV; neutral-relaxed pt1 at same N-N distance has EA -1.8635308/-1.2182879 eV. Thus N-N distance alone is not a sufficient state representation: other relaxed coordinates/electronic solutions differ. One cannot splice these curves into a barrier-free attachment path.

**neutral_sign_change**: For both bases first positive sampled neutral-path EA is pt6 at 1.74 A, bracketed by pt5 1.64 A negative. This is a sampled sign-change interval, not an optimized crossing seam or TS. Pt9 is excluded from a converged profile: 8 HURRAYs, error termination in PROPERTIES, Nalpha-C8=1.437 A and Si-Nalpha=1.609 A indicate a rearranged geometry; its completed SP remains a geometry-specific datum.

**dlpno_crossing_gap**: The actual driver chooses first positive anion-path TZVP point: pt1. Stored DLPNO anion_scan_EAvert_crossing input coordinates match that point. Only anion charge -1 mult2 was computed there; no DLPNO neutral at these same coordinates exists in the recovered family. Therefore no high-level EA at the alleged crossing and no high-level crossing location can be derived. Its anion energy is +0.54756835 eV above neutral minimum+free electron, not the vertical attachment threshold at neutral minimum (+0.39823255 eV).

**DEA**: E(RN-, optimized)+E(N2)-E(RN3,neutral minimum)=+0.01760908 eV at DLPNO. Near-thermoneutral electronic asymptote under these method/geometry/reference choices; no frequencies/ZPE/free-energy or capture kinetics. RN_triplet+N2 lies +1.27730125 eV; RN endpoint EA=1.25969217 eV compares distinct optimized endpoint geometries and is not vertical EA.

**interface_gap**: The isolated family cannot provide graphene electron removal/hole creation, image-charge/polarization, adsorbate level alignment, CT state, electronic coupling, hot-electron occupation, resonance lifetime or competition with detachment/N2-loss. Adjacent TMS_Q0/Q1/Q2 PBE CDFT directories exist, so interface evidence is not globally absent. Q1/Q2 have selective completed gs/ct_str0p20/ct_str0p30 files but missing low-strength and isolated-fragment outputs; their target population and W versus unbiased-density energy need a separate check before any injection threshold. This inventory does not certify those CT states.

**sidecar_convention**: The anion relaxscanscf.dat records uncorrected SCF energies; relaxscanact.dat records total corrected energies and agrees with output/XYZ. They are different conventions, not evidence of stale data. At pt1 SCF -573.39779978 Eh versus total -573.39011404643 Eh; r2SCAN-3c dispersion plus gCP corrections account for the difference. Comparisons here use FINAL SINGLE POINT ENERGY and matching XYZ headers throughout.

**completion_scope**: All 90 locally present isolated input run directories in archived and linked current roots inventoried; 78 step5 SP (72 scan-pair calculations+6 endpoint SP), six DLPNO SP, six initial opt/scan/endpoint runs. 36 paired EA(Q) comparisons complete, but two neutral-path pt9 basis pairs reference-only. This is remaining-coverage recovery, not a new scientific computation or blind test.

## Exact reusable sources

Archived raw root: `/home/sun07ao/grephene/research/pro_evidence_rebuild_20260915/raw_live_xj/entry_remaining/tms_arm/iso/TMS`
Linked current root: `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/tms_arm/iso/TMS`

Each `records` entry in observations.json includes full input/output path, method, charge/multiplicity, atom inventory, energy with original output line number, normal-termination line and coordinate list. `source_hashes` records SHA256 and byte length. `key_witnesses` retains original failure/selection lines. `scans` maps XYZ header energies to matching output lines, and preserves both SCF and corrected-total sidecar conventions. `copy_comparisons` shows the archived/current duplicate outputs tested were identical.

Reproduce with `python3 check.py`. Output stays in this audit directory. The script never executes source scripts or scientific software.
