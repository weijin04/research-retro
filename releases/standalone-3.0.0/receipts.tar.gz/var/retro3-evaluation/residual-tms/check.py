import pathlib,json,re,hashlib,math,collections,datetime
W=pathlib.Path(__file__).resolve().parent
P=pathlib.Path('/home/sun07ao/grephene')
A=P/'research/pro_evidence_rebuild_20260915/raw_live_xj/entry_remaining/tms_arm/iso/TMS'
L=P/'mech_loop/entry_competition_20260911/tms_arm/iso/TMS'
ev=27.211386245988; kcal=627.5094740631
hashes={}
def read(p):
 b=p.read_bytes();hashes[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b.decode(errors='replace')
def coords(t):
 return [(m[0],list(map(float,m[1:]))) for m in re.findall(r'^\s*([A-Z][a-z]?)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*$',t,re.M)]
records={};copies=[]
for rel in sorted(set(p.parent.relative_to(A) for p in A.rglob('orca.inp'))|set(p.parent.relative_to(L) for p in L.rglob('orca.inp'))):
 d=A/rel if (A/rel/'orca.out').exists() else L/rel
 inp=read(d/'orca.inp');out=read(d/'orca.out') if (d/'orca.out').exists() else ''
 energies=[{'line':i,'hartree':float(m.group(1))} for i,l in enumerate(out.splitlines(),1) if (m:=re.search(r'FINAL SINGLE POINT ENERGY\s+([-\d.]+)',l))]
 geom=coords(inp); q=re.search(r'\*\s*xyz(?:file)?\s+(-?\d+)\s+(\d+)',inp)
 rec={'directory':str(d),'input':str(d/'orca.inp'),'output':str(d/'orca.out'),'method':inp.splitlines()[0],'charge':int(q[1]),'multiplicity':int(q[2]),'normal':'ORCA TERMINATED NORMALLY' in out,'hurray_count':out.count('HURRAY'),'energy_records':energies,'geometry':geom,'composition':dict(collections.Counter(x[0] for x in geom)),'termination_line':next((i for i,l in enumerate(out.splitlines(),1) if 'ORCA TERMINATED NORMALLY' in l),None)}
 if (d/'orca.xyz').exists():rec['final_geometry']=coords(read(d/'orca.xyz'))
 records[str(rel)]=rec
 if (A/rel/'orca.out').exists() and (L/rel/'orca.out').exists():
  read(L/rel/'orca.out');copies.append({'relative':str(rel),'identical_output':hashes[str(A/rel/'orca.out')]['sha256']==hashes[str(L/rel/'orca.out')]['sha256']})
def energy(key):
 r=records[key];assert r['normal'] and r['energy_records'];return r['energy_records'][-1]['hartree']
pairs=[]
for path in ['neuscan','anscan']:
 for i in range(1,10):
  for basis in ['TZVP','TZVPD']:
   a=f'step5_sp/{path}_pt{i:02d}_neu_{basis}';b=f'step5_sp/{path}_pt{i:02d}_an_{basis}'
   if a not in records or b not in records:pairs.append({'path':path,'point':i,'basis':basis,'missing':[x for x in [a,b] if x not in records]});continue
   ga,gb=records[a]['geometry'],records[b]['geometry'];assert ga==gb
   pairs.append({'path':path,'point':i,'basis':basis,'Q_Nalpha_Nbeta_A':math.dist(ga[2][1],ga[1][1]),'EA_eV':(energy(a)-energy(b))*ev,'neutral_energy':energy(a),'anion_energy':energy(b),'sources':[a,b]})
dl={k.split('/')[-1]:energy(k) for k in records if k.startswith('step6_dlpno/') and records[k]['normal']}
comparisons={'DLPNO_EA_vertical_eV':(dl['neutral_min']-dl['vertical_anion_at_min'])*ev,'DLPNO_DEA_RNminus_plus_N2_minus_neutral_eV':(dl['RN_anion']+dl['N2']-dl['neutral_min'])*ev,'DLPNO_neutral_triplet_products_minus_neutral_eV':(dl['RN_triplet']+dl['N2']-dl['neutral_min'])*ev,'DLPNO_RN_endpoint_EA_eV':(dl['RN_triplet']-dl['RN_anion'])*ev,'DLPNO_crossing_anion_minus_neutral_min_eV':(dl['anion_scan_EAvert_crossing']-dl['neutral_min'])*ev}
assert records['step6_dlpno/neutral_min']['geometry']==records['step6_dlpno/vertical_anion_at_min']['geometry']
assert records['step6_dlpno/anion_scan_EAvert_crossing']['geometry']==records['step5_sp/anscan_pt01_an_TZVP']['geometry']
scans={}
for k in ['step2_neutral_scan','step3_anion_scan']:
 r=records[k];ds=pathlib.Path(r['directory']);g=[]
 for f in sorted(ds.glob('orca.[0-9][0-9][0-9].xyz')):
  ft=read(f);a=coords(ft);e=float(re.search(r' E\s+([-\d.]+)',ft)[1]);matches=[z for z in r['energy_records'] if abs(z['hartree']-e)<1e-10]
  g.append({'path':str(f),'Q_A':math.dist(a[2][1],a[1][1]),'NN_terminal_A':math.dist(a[0][1],a[1][1]),'header_energy_hartree':e,'header_line':2,'matching_output_records':matches,'converged_point':not (k=='step2_neutral_scan' and f.name=='orca.009.xyz'),'Nalpha_Si_A':math.dist(a[2][1],a[3][1]),'Nalpha_C_distances_A':{i:math.dist(a[2][1],x[1]) for i,x in enumerate(a) if x[0]=='C'}})
 scans[k]={'point_geometries':g,'energy_records':r['energy_records'],'normal':r['normal'],'hurray_count':r['hurray_count']}
for p in [L/'chain.log',L.parent.parent/'BRIEF.md',L.parent/'common/azide_chain.py']:
 if p.exists():read(p)
for b in ['TZVP','TZVPD']:
 en=lambda tag:energy(f'step5_sp/endpoint_RN_{tag}_{b}')
 comparisons[f'wB97X_{b}_RN_endpoint_EA_eV']=(en('triplet')-en('anion'))*ev
 comparisons[f'wB97X_{b}_RN_singlet_minus_triplet_eV']=(en('singlet_bs')-en('triplet'))*ev
neutral0=energy('step1_neutral_opt')
for k,s in scans.items():
 valid=[g for g in s['point_geometries'] if g['converged_point']]
 s['relative_to_neutral_min_eV']=[(g['header_energy_hartree']-neutral0)*ev for g in valid]
 s['sampled_range_relative_own_min_kcal_mol']=(max(g['header_energy_hartree'] for g in valid)-min(g['header_energy_hartree'] for g in valid))*kcal
 dp=pathlib.Path(records[k]['directory'])/'orca.relaxscanscf.dat'
 if dp.exists():
  txt=read(dp);s['sidecar_path']=str(dp);s['sidecar_rows']=[list(map(float,l.split())) for l in txt.splitlines() if l.strip()];s['sidecar_matches_current_xyz_energies']=all(abs(a[1]-b['header_energy_hartree'])<1e-7 for a,b in zip(s['sidecar_rows'],s['point_geometries']))
  act=dp.with_name('orca.relaxscanact.dat')
  if act.exists():
   s['corrected_sidecar_path']=str(act);s['corrected_sidecar_rows']=[list(map(float,l.split())) for l in read(act).splitlines() if l.strip()];s['corrected_sidecar_matches_current_xyz_energies']=all(abs(a[1]-b['header_energy_hartree'])<1e-7 for a,b in zip(s['corrected_sidecar_rows'],s['point_geometries']))
for pair in pairs:
 pair['geometry_qualification']='unconverged rearranged geometry; reference-only SP' if pair['path']=='neuscan' and pair['point']==9 else 'stored converged constrained r2SCAN scan geometry'
interface=[]
for root in [A.parent.parent/'tc_cdft/runs',L.parent.parent/'tc_cdft/runs']:
 for q in sorted(root.glob('TMS*')):
  for d in sorted(q.iterdir()):
   if not d.is_dir():continue
   outs=list(d.glob('*.out')); inps=list(d.glob('*.inp'))
   if not inps:continue
   inp=read(inps[0]);out=read(outs[0]) if outs else ''
   vals=[{'line':i,'energy_hartree':float(m[1])} for i,l in enumerate(out.splitlines(),1) if (m:=re.search(r'ENERGY\|.*?([-\d.]+)\s*$',l))]
   interface.append({'directory':str(d),'output_exists':bool(outs),'program_ended':'PROGRAM ENDED AT' in out,'energy_records':vals,'qualification':'inventory only; constraint achievement and consistent energy functional not audited'})
argument={
 'object':'Isolated C3H9N3Si, 16 atoms; q0 singlet and q-1 doublet, vacuum. RN endpoints C3H9NSi 14 atoms; neutral triplet/singlet and anion doublet, plus separately computed singlet N2. No graphene/hole/Fe in these isolated objects.',
 'methods':'r2SCAN-3c constrained relaxed scan B 2 1=1.24..2.04 Angstrom, 9 points; wB97X-D4/def2-TZVP and def2-TZVPD RIJCOSX neutral/anion SP pairs on identical coordinates; TightPNO DLPNO-CCSD(T)/aug-cc-pVTZ with aug-cc-pVTZ/C endpoints.',
 'EA_definition':'EA(Q)=E_neutral(Q)-E_anion(Q), free electron vacuum reference. Positive values mean the computed anion is lower than the specified neutral at identical Q and all remaining coordinates. Not direct interface-injection energy.',
 'path_distinction':'Anion-relaxed pt1 at 1.24 A already has EA 1.3183305/1.4284358 eV; neutral-relaxed pt1 at same N-N distance has EA -1.8635308/-1.2182879 eV. Thus N-N distance alone is not a sufficient state representation: other relaxed coordinates/electronic solutions differ. One cannot splice these curves into a barrier-free attachment path.',
 'neutral_sign_change':'For both bases first positive sampled neutral-path EA is pt6 at 1.74 A, bracketed by pt5 1.64 A negative. This is a sampled sign-change interval, not an optimized crossing seam or TS. Pt9 is excluded from a converged profile: 8 HURRAYs, error termination in PROPERTIES, Nalpha-C8=1.437 A and Si-Nalpha=1.609 A indicate a rearranged geometry; its completed SP remains a geometry-specific datum.',
 'dlpno_crossing_gap':'The actual driver chooses first positive anion-path TZVP point: pt1. Stored DLPNO anion_scan_EAvert_crossing input coordinates match that point. Only anion charge -1 mult2 was computed there; no DLPNO neutral at these same coordinates exists in the recovered family. Therefore no high-level EA at the alleged crossing and no high-level crossing location can be derived. Its anion energy is +0.54756835 eV above neutral minimum+free electron, not the vertical attachment threshold at neutral minimum (+0.39823255 eV).',
 'DEA':'E(RN-, optimized)+E(N2)-E(RN3,neutral minimum)=+0.01760908 eV at DLPNO. Near-thermoneutral electronic asymptote under these method/geometry/reference choices; no frequencies/ZPE/free-energy or capture kinetics. RN_triplet+N2 lies +1.27730125 eV; RN endpoint EA=1.25969217 eV compares distinct optimized endpoint geometries and is not vertical EA.',
 'interface_gap':'The isolated family cannot provide graphene electron removal/hole creation, image-charge/polarization, adsorbate level alignment, CT state, electronic coupling, hot-electron occupation, resonance lifetime or competition with detachment/N2-loss. Adjacent TMS_Q0/Q1/Q2 PBE CDFT directories exist, so interface evidence is not globally absent. Q1/Q2 have selective completed gs/ct_str0p20/ct_str0p30 files but missing low-strength and isolated-fragment outputs; their target population and W versus unbiased-density energy need a separate check before any injection threshold. This inventory does not certify those CT states.',
 'sidecar_convention':'The anion relaxscanscf.dat records uncorrected SCF energies; relaxscanact.dat records total corrected energies and agrees with output/XYZ. They are different conventions, not evidence of stale data. At pt1 SCF -573.39779978 Eh versus total -573.39011404643 Eh; r2SCAN-3c dispersion plus gCP corrections account for the difference. Comparisons here use FINAL SINGLE POINT ENERGY and matching XYZ headers throughout.',
 'completion_scope':'All 90 locally present isolated input run directories in archived and linked current roots inventoried; 78 step5 SP (72 scan-pair calculations+6 endpoint SP), six DLPNO SP, six initial opt/scan/endpoint runs. 36 paired EA(Q) comparisons complete, but two neutral-path pt9 basis pairs reference-only. This is remaining-coverage recovery, not a new scientific computation or blind test.'}
result={'evaluation_label':'revealed development residual recovery, not blind acceptance','source_roots':[str(A),str(L)],'records':records,'EA_Q_pairs':pairs,'DLPNO_energies':dl,'comparisons':comparisons,'scans':scans,'copy_comparisons':copies,'source_hashes':hashes,'adjacent_interface_inventory':interface,'argument':argument,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
result['key_witnesses']=[]
for path,pattern in [(A/'step2_neutral_scan/orca.out',r'HURRAY|error termination|aborting the run'),(L/'chain.log',r'first EA_vert|anscan pt01 EA'),(L.parent/'common/azide_chain.py',r'run_dlpno\("anion_scan|first EA_vert|sp_energies|if ok2'),(A/'step3_anion_scan/orca.inp',r'!|Scan B|xyz')]:
 text=read(path);result['key_witnesses'].append({'path':str(path),'matches':[{'line':i,'text':l} for i,l in enumerate(text.splitlines(),1) if re.search(pattern,l)]})
(W/'observations.json').write_text(json.dumps(result,indent=2))
print('COUNTS',len(records),collections.Counter(k.split('/')[0] for k in records));print('COMPARISONS',json.dumps(comparisons,indent=2));print('FAILED',[k for k,r in records.items() if not r['normal']]);print('DUPLICATE_DIFFS',[x for x in copies if not x['identical_output']]);print('INTERFACE inventory',len(interface));print('SCAN ranges',[(k,s['sampled_range_relative_own_min_kcal_mol'],s.get('sidecar_matches_current_xyz_energies')) for k,s in scans.items()])
