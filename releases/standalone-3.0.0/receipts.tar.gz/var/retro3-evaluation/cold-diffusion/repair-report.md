# diffusion 定向已揭示修复复查

结论：完整 FLEX shots 捕获修复通过。新包新增855078字节 whole_file（2527e31e…），JSON完整解析，1024条唯一shot；512条RIGID whole_file仍完整。旧131072字节截断片段仍以captured_segment保留，初评解析失败及原报告未改写。

只读指定新便携包及自己的评估文件，不访问原项目、不运行科学作业。沿用初评的独立加权公式，对每条 outcome 重新判 forward→j/backward→i，正 v_n 为权重，负/零 v_n 不计入分母；不使用保存的 reactive 布尔值代替重判。所得κ与stored κ逐项在1e-12内一致。

|mode|threshold|shots|positive|reactive|weighted kappa|
|---|---|---:|---:|---:|---:|
|flex|0.5ps|1024|499|303|0.830763416190|
|flex|1ps|1024|499|301|0.824838382094|
|flex|2ps|1024|499|301|0.823149434259|
|rigid|0.5ps|512|237|185|0.883896268072|
|rigid|1ps|512|237|183|0.873387262632|
|rigid|2ps|512|237|181|0.863745695676|

因此初评 static×κ_flex 比较中“仅引用文件头”的资格限制可在本次明确升级为“从完整1024 outcome记录独立重新加权”；数值不变。此复查没有从原始shot轨迹重新判承诺，也不认证积分通量、长时MSD拟合、联合停止或全项目覆盖。

已核验指定manifest SHA256为 e274a1825006354d98ebc36b0f5297a239d36758cc88bad41f28ca74f1241d77，所列全部文件哈希通过。repair-table.json含权重分子分母、shot计数和完整blob标识；repair-receipt.json含manifest检查与初评文件当前SHA256；repair-check.py可复现。作者叙述帮助/问题数：0（仅按已揭示修复任务获知新包路径和完整文件已补入）。

这是 targeted revealed repair recheck，不是新独立盲评。初评关于长轨迹fit/block条件、C-R/C-stab不可评估以及缺失完整长轨迹/科学资产的限制保持，未重复审核或给出更广覆盖通过。
