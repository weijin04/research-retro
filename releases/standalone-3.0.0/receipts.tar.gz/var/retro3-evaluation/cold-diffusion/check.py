from pathlib import Path
import json,math,re,hashlib
B=Path('/home/sun07ao/retro-workspaces/diffusion-retro3/exports/55fed8aa18a34ad2acf40e164166c9a0');O=Path(__file__).resolve().parent
H={'checkpoint':'bf48c41b39f678a888946c8851b805eddad87e63c1941cbb00e13fe1e868dd37','flux':'11842d621ffa7dc52763948d0f130cf3c8ac5f46ac390809956aeb35ede62997','flex':'6eb036ef4ebf4750fa0b1803a3651d407f5d8181f6fa39ed5a191a9cde870b24','rigid':'0773c49f58b282d90e68572effe567dde50fcf354d34a92d51a8feb3a09ebe40'}
T={k:(B/'store/blobs'/v).read_text() for k,v in H.items()}
c=json.loads(T['checkpoint'])['condition'];f=json.loads(T['flux']);rig=json.loads(T['rigid']);errors=[]
try: json.loads(T['flex'])
except json.JSONDecodeError as e:errors.append(str(e))
# Prefix is truncated: extract only declared header kappa, never relabel as shot-level recomputation.
kflex=json.loads(re.search(r'"kappa": (\{[^}]+\})',T['flex'])[1])
k={}
for key in ['0.5ps','1ps','2ps']:
 den=sum(max(0,x['v_n_A_fs']) for x in rig['outcomes'])
 num=sum(x['v_n_A_fs'] for x in rig['outcomes'] if x['v_n_A_fs']>0 and x['forward_commit'][key]==x['cage_j'] and x['backward_commit'][key]==x['cage_i'])
 k[key]=num/den
exposure=sum(x['duration_ps'] for x in c['replicas'])/1000
hops=sum(x['committed_hops']['2ps'] for x in c['replicas'])
D=sum(sum(x['D_axis_m2_s']) for x in c['replicas'])/(3*len(c['replicas']))
static=f['plane_analytic_D_mean_A2_ns']*1e-11
rows=[{'object':'FLEX 24-replica checkpoint mean','D_m2_s':D,'qualification':'recomputed per-replica axis mean; raw MSD fit not rerun'}, {'object':'static analytic flux','D_m2_s':static,'qualification':'captured numerical flux summary; A2/ns converted to m2/s'}, {'object':'static times flex kappa 1ps','D_m2_s':static*kflex['1ps'],'qualification':'flex kappa header only; full JSON truncated'}, {'object':'static times rigid kappa 1ps','D_m2_s':static*k['1ps'],'qualification':'rigid weighted kappa recomputed from 512 outcomes; not flexible prediction'}]
for row in rows:row['abs_log10_ratio_to_FLEX']=abs(math.log10(row['D_m2_s']/D))
lo,hi=c['diffusion']['D_iso']['ci95_log10'];half=(hi-lo)/2;residence=exposure/hops
r={'scope':'new project reader; cooperative bundle only; no OS enforced blind benchmark','author_questions':0,'rows':rows,'rigid_kappa_recomputed':k,'rigid_shots':len(rig['outcomes']),'flex_kappa_header':kflex,'first_failure_flex_json':errors,'hops':hops,'exposure_ns':exposure,'rate_ns_inverse':hops/exposure,'residence_ns':residence,'ten_residence_ns':10*residence,'fit_lower_ns':c['fit_window_ps'][0]/1000,'fit_pass':c['fit_window_ps'][0]/1000>10*residence,'ci95_halfwidth_dex':half,'C_hop':hops>=50,'C_D':half<=.1,'block_count':math.floor(c['block_bootstrap_check']['shortest_recorded_duration_ps']/c['block_bootstrap_check']['block_length_ps']),'C_R':'not evaluable','C_stab':'not evaluable','static_six_exit_rate_ns':6*f['plane_analytic_rate_ns']['mean']}
manifest=json.loads((B/'manifest.json').read_text());audit={p:{'sha256':hashlib.sha256((B/p).read_bytes()).hexdigest(),'matches':hashlib.sha256((B/p).read_bytes()).hexdigest()==h} for p,h in manifest['files'].items()}
(O/'receipts.json').write_text(json.dumps({'bundle':str(B),'used_blob_map':H,'manifest':audit},indent=2)+'\n');(O/'table.json').write_text(json.dumps(r,indent=2)+'\n')
lines=['|Object|D m2/s|absolute error to FLEX dex|','|---|---:|---:|']+[f"|{x['object']}|{x['D_m2_s']:.9g}|{x['abs_log10_ratio_to_FLEX']:.8f}|" for x in rows]
(O/'table.md').write_text('\n'.join(lines)+'\n');print(json.dumps(r,indent=2))
