# diffusion 新项目冷接手初评

结论：包支持一个有用但有界的接续：可以独立重算正式 rigid κ、static/FLEX 数值比较及长轨迹部分验收条件；不能完成全部 FLEX shot 独立复算，也不能认证整个项目或联合停止标准。未询问作者：**0 个问题**。

这是第一次接触此项目重建的读者；只读指定便携包，无原项目、其他代理结果、私人参考或 memory 访问。平台环境可能附带通用项目名摘要，因此不宣称信息上完全隔绝。限制是协作式 bundle-only，无 OS 隔离；没有科学作业或源项目写入。下述来源是捕获原件，不把 MAINLINE 当正确答案。

## 正式比较与适用范围

对象为 CH4/CHA、300 K、稀释 N=1 的 Hill–Sauer A 层模型；全体系 NHC、1 fs 和有定义的承诺事件协议是比较条件。它不是现实实验真值或未知材料 held-out 验证。输入实际使用 dt_fs 参数，本包 checkpoint/模型说明给出其 1 fs 条件；没有全部运行日志可逐一核实参数展开。

独立计算使用捕获的 converged_flux.json、完整 512 rigid shots 原结果、FLEX checkpoint 每副本三轴值。static 的 Å²/ns→m²/s 系数为 10^-11；单出口 0.040485122403/ns ×6=0.242910734420/ns。FLEX checkpoint 的 24×3 轴均值是 3.828361995e-11 m²/s。

|Object|D m2/s|absolute error to FLEX dex|
|---|---:|---:|
|FLEX 24-replica checkpoint mean|3.828362e-11|0.00000000|
|static analytic flux|3.88199868e-11|0.00604239|
|static times flex kappa 1ps|3.20202151e-11|0.07758875|
|static times rigid kappa 1ps|3.3904882e-11|0.05275076|

表中 rigid 修正对 FLEX 的误差只作共同数轴的描述，不是将 rigid κ 当 FLEX 正式预测，也不是无偏选择最佳修正。真正 static×κ_flex 的对比中，点误差从 0.00604 dex 增到 0.07759 dex，故当前参照不支持“加 κ 必有增量准确性”；这一个开发材料上的点估计亦不证明 static 泛化胜出。FLEX 参照自身的长时拟合与停止资格仍有限，不能把小误差当物理认证。

κ 采用 `sum(v_n>0 且 forward→j、backward→i 的 v_n)/sum(正 v_n)`，不是简单成功比例；commit.py 的承诺定义为累计停留达到阈值，而非必需连续停留。独立从完整 512 个 outcomes 重算 rigid κ(0.5/1/2 ps)=0.8838962681/0.8733872626/0.8637456957，否定沿用 8-shot smoke≈0.35 作为正式效应大小。输入中负 v_n 对分子分母均贡献零。

**初次实质失败保留**：flex kappa blob `6eb036ef…` 为截断 JSON，解析报 `Unterminated string starting at line 6273 column 7 (char 131071)`。因此表内 κ_flex=0.8248383821 只从完整文件头读取，后续乘法和误差独立重算，但不能声称重新加权完整 1024 shots。新包还含截断 rigid 片段和完整 rigid 结果，我选择完整 `0773c49f…` 成功核算。哈希相符不代表捕获内容完整。flex κ 及其全部 shot 物理解释仍缺一层独立复核。

## 数值完成与科学停止不是同一件事

checkpoint 记载 24 副本均到 2e8 steps；以 1 fs 为前提，每条 200 ns。前 20 ps 单独 dump，后续记录曝光由逐副本 duration 求和：24×199.98=4799.52 ns。独立合计 2 ps committed hops=1210，率=1210/4799.52=0.252108544/ns。

曝光/hop 得平均驻留估计 3.966545455 ns，10 倍=39.66545455 ns。原拟合窗为 10–40 ns，下界 10 ns 并不严格大于 39.665 ns，故长时窗规则失败；最大 lag 刚及 10 倍并不能让整个拟合区间合格。该估计隐含曝光/hop 对应统一驻留过程的假设，不独立证明 Poisson 或无记忆性。

95% log CI 半宽=(−10.3570327615−(−10.4900072647))/2=0.0664872516 dex≤0.10，C-D 通过；1210≥50，C-hop 通过，阈值按总组而非每副本。block 长度 200000 ps，而每条记录仅199980 ps，floor(199980/200000)=0，无法估计所定义 block bootstrap 检查。C-R 缺 RIGID-OPT 对照，C-stab 在该单条件文件也不可评估。因此四项联合 STOP-EARLY 未通过，即便工程上已按预算 RUN-TO-200 完成。

工程完成本身目前只由 checkpoint 和控制文档间接支持：本包未提供此24条运行的完整最终日志/每个 restart，无法再次独立核验每条 `Total wall time`、最终 restart 与无 lost-atoms。绝不把原文“DONE”升格为本次检查到所有终止原件。

## 具体下一分析及不重复路线

优先做 **同一 A 层 FLEX 参照的拟合窗资格分析**，不再增加 MD：取已有24条200 ns原轨迹，保留原来 guest unwrapping、框架参考和副本分组，先预设 lag 窗 40–60、40–80、50–100 ns，分别带截距拟合逐轴 MSD 与 isotropic D；报告 lag-dependent slope、replica bootstrap、窗间漂移，不只挑最接近 static 的窗。40 ns 下界仅略超本次39.665 ns门，必须在各估计更新驻留时间后再次查门。每条200 ns只有约2个不重叠100 ns块，因此不能把大量重叠 time origins 当独立副本；若改变 block 规则须先说明是新敏感性分析，不能重命名为已通过旧200 ns block gate。

输出应是“不同合格候选窗下 static 与 κ_flex 点误差/CI 的比较”，先恢复完整 FLEX κ原件并按同一权重核算，再决定组件增益是否可判。缺 RIGID-OPT 时 C-R 保持缺失，不以现有 RIGIDFAST 名字替代不同预注册协议。不得用同 seed 的 xj 与曙光副本池化提升名义样本量。

这避免已失效的“单原子 NVT DOF 陷阱下零 hop→柔性导致扩散”的旧刚性比较，也避免用 σ/ε 扫描拟合已知 D（违背原项目校准隔离），或继续引用 8-shot κ≈0.35。包内 controls 的早期现实差距/OPEN 字句明显含历史版本，不能因为文件名 canonical 就覆盖更晚完整数值。

## 缺资产和验收范围

完成有界判断无需作者补叙述，问题数0。真正执行上述重新拟合尚需24条FLEX长轨迹与相应分析代码/元数据；本包捕获的是 checkpoint 和另三条 loading/rigid r1 轨迹，不能用它们冒充24副本参照。还需完整1024 FLEX shots结果（若重建承诺需 shot轨迹/manifest）、static 原npz/积分代码以验证通量积分本身、完整正式停止准则文档和RIGID-OPT相关资产。它们的缺失不妨碍本次算术反证，但限制全链复现。

本次 check.py 实际运行；table.json 保存公式结果及首个JSON解析失败，table.md 为表，receipts.json 为包路径、blob映射和 manifest逐文件哈希。所有 manifest 哈希匹配仅认证已捕获字节。评估结论是 **scoped useful handoff / partial reconstruction**，不是whole-project sufficiency，也不替换未完成的科学验收。
