|Object|D m2/s|absolute error to FLEX dex|
|---|---:|---:|
|FLEX 24-replica checkpoint mean|3.828362e-11|0.00000000|
|static analytic flux|3.88199868e-11|0.00604239|
|static times flex kappa 1ps|3.20202151e-11|0.07758875|
|static times rigid kappa 1ps|3.3904882e-11|0.05275076|
