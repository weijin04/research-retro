import re,json,hashlib,math
from pathlib import Path
R=Path('/home/sun07ao/grephene'); D=Path(__file__).resolve().parent
EXP=Path('/home/sun07ao/retro-workspaces/grephene-retro3/exports/bd35f30257214f3f8c0deb2c7842b9ec')
S={};obs={}
def read(p):
 p=Path(p);b=p.read_bytes();S[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b.decode()
def energy(p):
 s=read(p);m=list(re.finditer(r'^FINAL SINGLE POINT ENERGY\s+([-\d.]+)',s,re.M));assert m,p
 a=m[-1];return {'path':str(p),'E_Eh':float(a[1]),'line':s[:a.start()].count('\n')+1,'normal':'ORCA TERMINATED NORMALLY' in s,'HURRAY':'HURRAY' in s,'first_E_Eh':float(m[0][1])}
def geom(p):
 s=read(p).splitlines();return [(l.split()[0],list(map(float,l.split()[1:4]))) for l in s[2:2+int(s[0])]]
def distances(p,n):
 x=geom(p);return {'path':str(p),'atom':n,'element':x[n][0],'C_neighbors_2A':[(i,math.dist(x[n][1],r)) for i,(e,r) in enumerate(x) if e=='C' and math.dist(x[n][1],r)<2],'N_neighbors_2A':[(i,math.dist(x[n][1],r)) for i,(e,r) in enumerate(x) if e=='N' and i!=n and math.dist(x[n][1],r)<2]}
A=R/'MECHANISM_FIELD_AUDIT_20260907/01_INVENTORY/RAW_CACHE/xj/s5_followups'
ref=energy(A/'T6p/d_mult6/orca.out');caps=[]
for name in ['T14_capped_m4','T15_capped_m2']:
 e=energy(A/name/'orca.out');e['delta_to_m6_kcal_mol']=(e['E_Eh']-ref['E_Eh'])*627.5094740631;caps.append(e)
obs['capped_spin']={'reference':ref,'states':caps}
obs['T13b_rebond']=[distances(A/f'T13b_cn_scan/orca.00{i}.xyz',72) for i in [1,6,7]]
T=R/'research/pro_evidence_rebuild_20260915/raw_live_xj/entry_remaining/tms_arm/iso/TMS/step6_dlpno'
n=energy(T/'neutral_min/orca.out');a=energy(T/'vertical_anion_at_min/orca.out')
I=R/'mech_loop/entry_competition_20260911/tms_arm/iso/TMS/step6_dlpno'
ni=read(I/'neutral_min/orca.inp');ai=read(I/'vertical_anion_at_min/orca.inp')
coords=lambda s:s.split('* xyz ')[1].split('\n',1)[1].strip()
obs['TMS_vertical_EA']={'neutral':n,'anion':a,'EA_eV':(n['E_Eh']-a['E_Eh'])*27.211386245988,'same_coordinates':coords(ni)==coords(ai),'method':'DLPNO-CCSD(T)/aug-cc-pVTZ TightPNO','interpretation':'isolated vertical attachment, not interface triplet CT'}
H=R/'gate_bc_competing/gate_d_neb/h3_consistent_mep_sp'
sp=energy(H/'octet_mep/pt1_h1_intact/orca.out');op=energy(H/'octet_opt_pt1/orca.out')
obs['octet_reference_relaxation']={'sp':sp,'opt':op,'opt_minus_sp_kcal_mol':(op['E_Eh']-sp['E_Eh'])*627.5094740631}
read(H/'octet_opt_pt1/orca.inp');read(H/'octet_mep/pt1_h1_intact/orca.inp');read(H/'README.md')
Q=R/'mech_loop/r4q_azide_down_triazoline'
obs['r4q_seed']=[distances(Q/'B_center_m6/geom.xyz',103)] if (Q/'B_center_m6/geom.xyz').exists() else []
for name in ['B_center_am5','B_edge_m6']:
 x=geom(Q/name/'geom.xyz');obs['r4q_seed'].append({'path':str(Q/name/'geom.xyz'),'Na_Ng_A':math.dist(x[103][1],x[105][1]),'Fe_Nb_A':math.dist(x[88][1],x[104][1])})
read(Q/'rebuild/build_triazoline.py');read(Q/'rebuild/w150/orca.inp');read(Q/'RESULTS_R4Q.md')
qb=energy(Q/'A_bridge_am5/orca.out');qw=energy(Q/'rebuild/w150/orca.out')
obs['r4q_corrected_slice']={'baseline':qb,'window':qw,'window_minus_min_kcal_mol':(qw['E_Eh']-qb['E_Eh'])*627.5094740631,'charge':-1,'multiplicity':5,'constraint_pairs_0based':[[40,103],[53,105]],'target_A':1.5}
P=R/'research/pro_evidence_rebuild_20260915/raw_live_xj/entry_remaining/product_family/P12_wb97x_exit_envelope'
pc=energy(P/'closed_m6/orca.out');pp=energy(P/'exitpeak_m4/orca.out')
obs['P12_product_exit']={'closed':pc,'sampled_peak':pp,'gap_kcal_mol':(pp['E_Eh']-pc['E_Eh'])*627.5094740631,'not':'certified transition state or thermal free-energy barrier'}
photo=[R/'expert_system_contrast_20260422/stage3_photoresponse_5x3/encounter_m6_tddft_dz/orca.inp',R/'stage3_photoresponse_5x3/encounter_m6_tddft_dz_wb97d4_final/orca.inp']
obs['photo_repeat']=[{'path':str(p),'method_line':read(p).splitlines()[0]} for p in photo]
for p in [R/'mech_loop/s5_followups/RESULTS.md',R/'mech_loop/CANDIDATE_MECHANISM_v3_20260906.md',R/'research/scientific_evidence_map_20260915/FORGOTTEN_ASSETS.md',R/'research_atlas_20260913/ROUTE_LINEAGE.md',EXP/'SCIENTIFIC_STATE.json',EXP/'MAINLINE.md',EXP/'SOURCE_INDEX.json']:read(p)
(D/'observations.json').write_text(json.dumps(obs,indent=2)+'\n');(D/'source_hashes.json').write_text(json.dumps(S,indent=2)+'\n')
print(json.dumps(obs,indent=2))
