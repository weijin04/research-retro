# 已揭示修复复查：有限接续通过，全项目仍 draft

本次明确知道初评问题和修复目标，属于 revealed repair recheck，不能计作新的独立盲评或普遍未见项目基准。初始 report.md、numbers.json、check.py、sources.sha256.json 均未改写。本次仅读 bd35f30257214f3f8c0deb2c7842b9ec 便携包及自己的初评；不读原项目，不运行包内 collector/build 脚本，不执行科学作业。访问仍是协作式限制，无 OS 隔离。

## 对初评问题的复查

- **CI 算术修正通过**：从原 ORCA PATH SUMMARY 重新解析，CI−R=15.29240588297418 kcal/mol，修正正文为 15.292406，与原件一致。原始能量打印精度的资格限制不变。
- **D 对象映射修正通过**：新增 BUILD.json 给出确切 pairs。按原 D XYZ 重算 C_N_keep=C41–N88=1.509421 Å；C_N_break=C28–N88=2.364441 Å；C_O=C28–O91=3.728182 Å。之前 C29–O91=3.100529 Å 是另一对原子，不能与 C_O 比较。两个 N–H 分别 1.027372/1.017913 Å。几何账本现可在包内直接复核，仍不认证 NO3 的电子电荷分区。
- **原件导航显著改善**：SOURCE_INDEX.json 有 48 个源路径，均能映射到存在且字节长度匹配的 blob；manifest 所列文件 SHA256 全部通过。读者现在可按旧相对路径找到已捕获原件，而不必解析庞大 handoff。SOURCE_INDEX 是捕获索引，未把所有未捕获内层引用自动变成可用资产。
- **全索引与全原件已区分**：CALC_INDEX.tsv 作为 whole_file 捕获，解析得 2663 行数据，可查旧计算/重复劳动风险；这不等于 2663 行所指计算均已打包。新正文明确“不全数打包”，修复了初评对完整性措辞的核心异议。
- **可选代码可审阅，不等于随处可运行**：collect.py 仍依赖本地 BUILD/path_parser/thermo_active、原目录，并可 fetch/写文件；本次未执行。所捕获 NH_exit2/thermo_active.py 明确要求 90 原子、270 模式、44 冻结原子，不能直接套用 92 原子 NH 邻对。extract_phi.py 需要完整匹配 cube/输出，parse_fermi 采用文件最后匹配值，使用者必须先保证日志块与帧匹配。新正文正确保留这些边界。

## 新的有限接续任务：重建 C3 并判定 C4

从原 make_c4.py **只读取**路径优先级及 gate 语句，自编 repair-check.py 解析四份 RESTART/C3_free 的输入、XYZ 和原始输出。逐项检查 C32、Fe72、N87、N88 的元素，按笛卡尔坐标直接计算距离；Na 是此脚本给 Nα 的标签，不是 Na 元素。

|case|q/m|N87–C32 Å|Fe72–N87 Å|N87–N88 Å|HURRAY/normal|frozen|C4 gate|
|---|---|---:|---:|---:|---|---|---|
|C2_capture_m4_FeN250|0/4|3.271450|1.868167|1.211960|True/True|{'C': 18, 'H': 18}|False|
|C2_capture_m4_FeN310|0/4|3.259512|1.868121|1.211974|True/True|{'C': 18, 'H': 18}|False|
|C2_capture_m6_FeN250|0/6|3.208128|1.882814|1.198666|True/True|{'C': 18, 'H': 18}|False|
|C2_capture_m6_FeN280|0/6|3.233273|1.895170|1.201494|True/True|{'C': 18, 'H': 18}|False|

距离单位 Å，编号从 0 开始，方法为输入中的 UKS r2SCAN-3c。四项均 90 原子。用正则从每份输入取得 36 个 Cartesian 约束索引，再在各自 XYZ 中逐个查询元素，均为 18C+18H；四份约束索引与 F0 原输入相同。原 ORCA `{ C i C }` 的 C 表示笛卡尔约束，不代表元素碳；旧 make_c4 的“36 frozen edge C”注释与真实对象不符。完整索引/元素列表已保存 repair-table.json。

原始 C4 判据为 `HURRAY and N87–C32 < 1.70 Å and Fe72–N87 > 2.10 Å`。四项都通过数值完成项，且都同时违反两个几何项，因此实际下一步是 **不构建这四项 C4**。它们在这些初始构象、多重度、方法和冻结边界下未保住所需 C–N 中间体，已返回 Fe 接触态。该结论不排除其他构象/环境/自旋或协同、激发态途径。

如果日后出现通过门的 C3，旧构建器才会提出 N87–N88 从当前距离到 2.30 Å 的 9 点 relaxed scan，保持对应多重度及同一冻结边界，Fe–N87 与 N87–C32 不约束。这是下一步设计，不是本次构建/提交结果，也不是扫描自动等价于认证 TS。原 builder 还需 GBW 与 run.sh 运行模板等；包内 gate 可执行复查不意味着完整量化提交资产已齐。

## 总结与剩余缺项

本次确实完成了新增且有用的包内工作：四条几何表、冻结元素辨认和 C4 投入决策都由原件算得，不依赖原作者口述，也没有重复量化计算。初评的算术、D 映射和查找入口问题已修复；全索引的可复用价值成立。

完整科学/计算接续仍需二进制轨道、匹配大 cube、未完成 Hessian、相关运行依赖以及实验原谱/样品与 KPFM 元数据。现有 48 原件覆盖关键审计支线，不构成整个项目的全部证据；历史报告中的广泛路线裁决仍不能逐条都由本包重新审判。因此维持 **full-project draft；bounded continuation demonstrated**，不是机制闭合或完整项目验收通过。

复现：`python3 repair-check.py`，只读取本包并写本评估目录。收据：repair-table.json、repair-table.md、repair-sources.json。初评文件 SHA256 记录在 repair-table.json 供后续确认冻结版本。
