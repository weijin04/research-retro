from pathlib import Path
import json,re,hashlib,math,collections
B=Path('/home/sun07ao/retro-workspaces/grephene-retro3/exports/8e1d3aaa4aaf4d3eaf1d3c0877d0dfab')
O=Path(__file__).resolve().parent
H={'A':'1af9084d2ac71cea1586b21754ec5463d250a21318ef6d190eccca9aea5f5d64','F':'80d17da36a59f37bb1285ed9696a72d6d1773e6f3c3a725f447ad355b838d17e','TMSN3':'8b23b9b7937f8bbcda0dac4c4fc1a086d16d8c39a705b32de8729c10f447dad1','TMSONO2':'b610f57888461b033d28666cfcb26e02311b6e42d531d3c5a9b4e7062513bca4','Q':'285974ec9bf26f8dc20f86b4c852cfdf7900c1e0f826d71b7e2e7d260e4eb663','D':'15405c38d962f2d358ba9d8ce4e931e393a0fac7dd32917022b9843da9355f4e','D_xyz':'20e81dd838fa886d9ac7554853d88ee1bfcbc58f5529309eb161f048b9781137','pair':'cbb5c85b3bc02bbfba7ad803dcd9fd3d6be8e3a54d38e240613f65e2929536c8','A_repair':'aef3c83573c761b96f135d47ff64f2707efef4c7f2da45ae7744531ddafe7211'}
T={k:(B/'store/blobs'/v).read_text() for k,v in H.items()}
K=627.5094740631
energies={k:float(re.findall(r'FINAL SINGLE POINT ENERGY\s+(-?[\d.]+)',T[k])[-1]) for k in ['A','F','TMSN3','TMSONO2','Q','D']}
p=T['pair'][T['pair'].rfind('PATH SUMMARY FOR NEB-TS'):]
path={m[0]:float(m[1]) for m in re.findall(r'^\s*(\d+|TS)\s+(-\d+\.\d+)\s',p,re.M)}
def xyz(t):
 return [(m[0],tuple(map(float,m[1:]))) for m in re.findall(r'^\s*([A-Z][a-z]?)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s*$',t,re.M)]
D=xyz(T['D_xyz'])
qblock=T['Q'].split('CARTESIAN COORDINATES (ANGSTROEM)')[-1].split('CARTESIAN COORDINATES (A.U.)')[0]
Q=xyz(qblock)
def geometry(a):
 return {'atom_count':len(a),'formula_counts':dict(collections.Counter(x[0] for x in a)), 'selected_distances_zero_based_A':{f'{a[i][0]}{i}-{a[j][0]}{j}':math.dist(a[i][1],a[j][1]) for i,j in [(29,91),(29,88),(30,88)]},'N_to_carbon_below_1_8_A':[(i,j,math.dist(x[1],y[1])) for i,x in enumerate(a) if x[0]=='N' for j,y in enumerate(a) if y[0]=='C' and math.dist(x[1],y[1])<1.8], 'O_to_C_min_A':{str(i):min(math.dist(x[1],y[1]) for y in a if y[0]=='C') for i,x in enumerate(a) if x[0]=='O'}}
rows=[{'object':'G0 A+TMSONO2 minus F+TMSN3','value':(energies['A']+energies['TMSONO2']-energies['F']-energies['TMSN3'])*K,'unit':'kcal/mol','reference':'F+TMSN3 gas electronic energy','qualification':'r2SCAN-3c; A has imaginary frequency; not validated RRHO free energy'}, {'object':'D_RKS minus Q','value':(energies['D']-energies['Q'])*K,'unit':'kcal/mol','reference':'Q same composition q0 M1 r2SCAN-3c','qualification':'Q NumFreq unfinished; electronic comparison only'}]
for key in ['2','TS','9']:
 rows.append({'object':'adjacent NH pair '+key,'value':(path[key]-path['0'])*K,'unit':'kcal/mol','reference':'same NEB-TS reactant image 0, C66H24N2 q0 M1 r2SCAN-3c frozen cluster','qualification':'printed energies 5 decimals Eh; ~0.0063 kcal/mol difference rounding bound; no validated thermal barrier'})
r={'bundle':str(B),'constant_Eh_to_kcal_mol':K,'energies_Eh':energies,'path_Eh':path,'results':rows,'geometry':{'D':geometry(D),'Q':geometry(Q)},'imaginary_modes':{k:re.findall(r'^.*imaginary mode.*$',T[k],re.M) for k in ['A','A_repair','Q']},'normal_termination':{k:'ORCA TERMINATED NORMALLY' in t for k,t in T.items() if k!='D_xyz'}}
manifest=json.loads((B/'manifest.json').read_text())
audit=[]
for name,expected in manifest['files'].items():
 actual=hashlib.sha256((B/name).read_bytes()).hexdigest()
 audit.append({'path':name,'sha256':actual,'matches_manifest':actual==expected})
r['manifest_all_match']=all(x['matches_manifest'] for x in audit)
r['captured_artifact_paths']=[x['data'].get('path') for x in json.loads((B/'handoff.json').read_text())['records'] if x['kind']=='artifact']
(O/'numbers.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
(O/'sources.sha256.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['results','geometry','manifest_all_match','captured_artifact_paths']},ensure_ascii=False,indent=2))
