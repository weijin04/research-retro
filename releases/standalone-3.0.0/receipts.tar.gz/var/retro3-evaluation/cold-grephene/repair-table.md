|case|q/m|N87–C32 Å|Fe72–N87 Å|N87–N88 Å|HURRAY/normal|frozen|C4 gate|
|---|---|---:|---:|---:|---|---|---|
|C2_capture_m4_FeN250|0/4|3.271450|1.868167|1.211960|True/True|{'C': 18, 'H': 18}|False|
|C2_capture_m4_FeN310|0/4|3.259512|1.868121|1.211974|True/True|{'C': 18, 'H': 18}|False|
|C2_capture_m6_FeN250|0/6|3.208128|1.882814|1.198666|True/True|{'C': 18, 'H': 18}|False|
|C2_capture_m6_FeN280|0/6|3.233273|1.895170|1.201494|True/True|{'C': 18, 'H': 18}|False|
