# diffusion 初始盲构建评估

冻结四题：15/16；题内重大科学错误0。D1=4、D2=3、D3=4、D4=4。它仍为draft，本结果不替代全项目覆盖与冷接手验收。

**D1 4/4**：正确分离24×200 ns FLEX、1210 hops、4799.52 ns、D与未过联合收敛门；checkpoint原件完整捕获，fit/window和block bootstrap限制正确。未独立重跑全量trajectory，产品已明确。 边界：冻结参考另列 replica1 log 未捕获，因此不升级为24条原始log逐条独立完成审计。

**D2 3/4**：三种time κ逐项正确；明确正vn weighting、committed definition、旧0.35失效和单window范围。独立原件已核数字吻合。 边界：shot结果仅捕获131072字节前缀、不是合法完整JSON，512条重求和不能仅凭离线bundle完成；产品已诚实注明需原件路径。扣1分为portable raw-level reproducibility缺口，不是数字错误。

**D3 4/4**：明确研究paused、新计算需恢复授权；现有outcomes统一定义是具体可做任务，冻结新材料评测先于迁移，开发点不能冒充held-out成功。 边界：冻结参考所列loading待判读来自较旧控制面；该构建已有后续showcase raw recheck，不强求重复过时任务。评分承认有原件支撑的更新。

**D4 4/4**：已自然正确识别ten_residence_ns=39.6654545；明确这是十倍驻留并非平均值，10ns判据仍失败。checkpoint原件提供mean=3966.545ps，足以恢复3.9665ns。 边界：没有在正文单列mean数值，不构成错误；现有原件与正确十倍标签足以回答。

封存 staged revision 已自然被初始构建发现：MAINLINE 310–312明确39.665ns是十倍驻留且判据不通过。因此不构成未知新证据测试，不应假造阶段释放成功。可改用评估者在grephene初始构建之后发现的D原子索引映射错误进行真实纠错出口检查，注明其发现来源。
