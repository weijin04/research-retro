from pathlib import Path
import re,json,hashlib,math,collections,time
P=Path(__file__).parent;R=Path('/home/sun07ao/grephene');B=R/'gate_bc_competing/gate_d_neb/h3_consistent_mep_sp';S={}
def read(p):
 p=Path(p);b=p.read_bytes();S[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'line_count':len(b.splitlines())};return b.decode()
def xyz(p):return [x.split() for x in read(p).splitlines()[2:]]
def dist(a,i,j):return math.dist(list(map(float,a[i][1:])),list(map(float,a[j][1:])))
def lines(t,pat):return [i for i,l in enumerate(t.splitlines(),1) if re.search(pat,l)]
def obj(a,fe,natoms,carbon):
 return {'atom_count':len(a),'composition':dict(collections.Counter(x[0] for x in a)),'Fe_index_0based':fe,'azide_indices_0based':natoms,'nitrogen_distances':[{'N':n,'Fe_N_A':dist(a,fe,n),'other_N_A':{str(m):dist(a,n,m) for m in natoms if m!=n},'two_nearest_sheet_C':sorted((dist(a,n,c),c) for c in range(carbon))[:2],'nearest_H':min((dist(a,n,h),h) for h,x in enumerate(a) if x[0]=='H')} for n in natoms]}
pts=[]
for p in sorted(B.glob('pt*/geom.xyz')):
 a=xyz(p);inp=read(p.parent/'orca.inp');out=read(p.parent/'orca.out');v=obj(a,88,[103,104,105],66);v.update(id=p.parent.name,geometry=str(p),input=str(p.parent/'orca.inp'),output=str(p.parent/'orca.out'),method=inp.splitlines()[0],qm=re.findall(r'xyzfile\s+(-?\d+)\s+(\d+)',inp),energy_Eh=float(re.findall(r'FINAL SINGLE POINT ENERGY\s+(\S+)',out)[-1]),normal='ORCA TERMINATED NORMALLY' in out,energy_lines=lines(out,'FINAL SINGLE POINT ENERGY'),atom_lines={'Fe88':91,'Na103':106,'Nb104':107,'Ng105':108});pts.append(v)
for p in [B/'README.md',B.parent/'h1h2_relaxed_scan/ARCHIVED.md',B/'yamaguchi_stepwise_sp/STEPWISE_YAMAGUCHI_VERDICT_20260705.md']:read(p)
def optical(out):
 t=read(out);result={}
 for gauge,marker in [('length','ABSORPTION SPECTRUM VIA TRANSITION ELECTRIC DIPOLE MOMENTS'),('velocity','ABSORPTION SPECTRUM VIA TRANSITION VELOCITY DIPOLE MOMENTS')]:
  start=t.rfind(marker)
  block=t[start:start+5500];arr=[]
  for m in re.finditer(r'^\s*0-\S+\s+->\s+(\d+)-\S+\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)',block,re.M):arr.append({'root':int(m[1]),'eV':float(m[2]),'nm':float(m[4]),'f':float(m[5])})
  result[gauge]=arr[:20]
 result['input_lines']=lines(t,r'\|.*(!|xyzfile|NRoots|TDA|STAB)');result['absorption_lines']=lines(t,'ABSORPTION SPECTRUM');return result
old=R/'gate_bc_competing/nto_analysis/encounter_corrected';ot=read(old/'orca.out');m=re.search(r'CARTESIAN COORDINATES \(ANGSTROEM\)\s*\n-+\s*\n([\s\S]*?)\n\s*\n',ot);oa=[l.split() for l in m[1].splitlines()];oldobj=obj(oa,88,[103,104,105],66)
new=R/'mech_loop/rep_armchair_flake/complex_tda_m6_pbe0';na=xyz(new/'geom.xyz');newinp=read(new/'orca.inp');newobj=obj(na,120,[135,136,137],96)
def fractions(p,groups):
 t=read(p);a={}
 for m in re.finditer(r'^\s*(\d+)\(([A-Za-z]+)\s*\)\s*Hole:\s*(-?[\d.]+)\s*%\s*Electron:\s*(-?[\d.]+)\s*%',t,re.M):a[int(m[1])]=(float(m[3]),float(m[4]))
 return {'atoms_read':len(a),'groups':{k:{'hole_percent':sum(a.get(i,(0,0))[0] for i in ids),'electron_percent':sum(a.get(i,(0,0))[1] for i in ids)} for k,ids in groups.items()},'atom_table_lines':lines(t,r'\)\s*Hole:')}
fr={};groups={'sheet':range(1,89),'Fe':[89],'nitrate':range(90,98),'MeCN':range(98,104),'azide':range(104,107)}
for name in ['holeelec_state17_mull.log','holeelec_state18_mulliken.log','holeelec_state19_mulliken.log']:fr[name]=fractions(old/name,groups)
ng={'sheet':range(1,121),'Fe':[121],'nitrate':range(122,130),'MeCN':range(130,136),'azide':range(136,139)}
for n in [1,17,20]:fr['armchair_state'+str(n)]=fractions(new/f'holeelec/state{n}_mull.log',ng)
# Explicit original-based provenance check: new fragment was grafted from a1b, not identical to old optical structure.
graft=R/'mech_loop/rep_armchair_flake/build_and_graft.py';read(graft)
read(R/'mech_loop/rep_armchair_flake/BUILD.md')
oldnew_max=max(abs(dist(oa,88+i,88+j)-dist(na,120+i,120+j)) for i in range(18) for j in range(i))
result={'label':'post-reveal residual scientific recovery; not evaluation','time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'indexing':'all atom indices0-based unless group ranges explicitly1-based','six_points':pts,'old_photoentry':{'object':oldobj,'optical':optical(old/'orca.out'),'model_input_embedded':str(old/'orca.out')},'new_armchair_control':{'object':newobj,'input':newinp,'optical':optical(new/'orca.out')},'hole_electron_recomputed':fr,'max_old_optical_vs_new_fragment_pair_distance_difference_A':oldnew_max,'limits':['H1/H2 retained-N atom identity identified; no continuous path/MECP or N-transfer dynamics established','Geometry labels do not prove stationary TS or nitride identity','Photoentry comparison changes sheet size/edge, functional, geometry/reference state simultaneously; not a controlled factor effect','New20-root PBE0 armchair output ends below532nm energy; cannot infer absence of532nm states','No raw NTO wavefunction reprocessing, only existing per-atom hole-electron logs summed','Old optical length/velocity gauges differ substantially; retain both, do not silently select historical oscillator strength','No experimental mechanism, kinetics or yield follows from these local spectra']}
(P/'observations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(P/'source_hashes.json').write_text(json.dumps(S,indent=2)+'\n');print(json.dumps({'points':[(x['id'],x['energy_Eh']) for x in pts],'oldnew_fragment_difference':oldnew_max,'old17':result['old_photoentry']['optical']['length'][16],'old17velocity':result['old_photoentry']['optical']['velocity'][16],'new20':result['new_armchair_control']['optical']['length'][-1],'fractions':{k:v['groups'] for k,v in fr.items()}},indent=2))
