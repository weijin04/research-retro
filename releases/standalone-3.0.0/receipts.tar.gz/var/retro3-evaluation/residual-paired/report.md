# Paired/dual-anchor and vacancy residual discovery

Revealed development discovery, not unseen acceptance and not a change to the frozen comparison. Original scientific project was read-only; no jobs or source-writing scripts were run. This audit follows the paired/coverage counterexample T5 and S1 monovacancy attempt, not a new desired mechanism.

## Paired means two intact N3 groups here

`mech_loop/a3_gn3_triad/c54_fast/T5_14` is a 78-atom C54H18N6 neutral restricted singlet (384 electrons), not a single N bridging two carbon atoms and not an Fe-containing cage. Two intact N3 groups attach at distinct C31/N72 and C22/N75 anchors (zero-based). r2SCAN-3c Opt, 36 frozen atoms are **18 edge C + 18 H**, not 36 C. Input lines 1–44 define method, fixed atoms and 0/1. ORCA output explicitly uses RHF-type restricted orbitals; frequency or wavefunction-stability certification was not recovered.

Direct endpoint distances: C31–N72=1.569660 Å and C22–N75=1.569700 Å; N–N sequences 1.225055/1.137346 and 1.225027/1.137312 Å. Output has HURRAY and normal termination. Using original T0a flake and T0b neutral-doublet N3 energies, the actual same-stoichiometry subtraction is

`[-2396.759082703912 − (-2068.524890766843) − 2(-164.116178886075)] × 627.5094740631 = −1.150955864 kcal/mol`.

This is weakly favorable electronic association within this finite frozen-edge model. It is a real counterexample to the universal statement that no intact N3-on-carbon bound optimization endpoint exists. It is not demonstrated formation probability, a frequency-certified minimum, a solution/film free energy, or a mechanism for azide disappearance. The two groups remain intact; subsequent N2 loss and true coverage/accessibility must be established separately. Reuse the existing endpoint for an explicitly scoped downstream question, not as a new independent vote for any upstream Fe/photo mechanism. Reopening a full paired pathway requires encounter/coverage evidence and a viable formation route, then the downstream transformation and thermal exit relevant to the experiment.

The companion `T5_12` is the same composition/charge/multiplicity and boundary, but adjacent C31/C20 anchors. It has neither HURRAY nor normal termination. The last stored trajectory frame has C31–N72=3.262371 Å and C20–N75=3.286989 Å, with both N3 groups intact. This is an interrupted trajectory drifting away from the intended covalent geometry, not a completed negative search or proof that every 1,2 structure is impossible. Its last SCF energy must not be ranked as a converged covalent 1,2 product. The older explanation “steric repulsion caused failure” is plausible interpretation, not independently isolated by this comparison.

## Vacancy: originals survive even when the active directory lacks outputs

`mech_loop/s1_defect_capture/RESULTS.md:3–18` records removing original C31 from C54H18 with no added H. Inputs and coordinates verify C53H18 (71 atoms, 336 electrons) for V0 and C53H18N3 (74 atoms, 357 electrons) for V1. The even-electron vacancy requires odd multiplicity; V0 m1/m3 and odd-electron V1 m2/m4 are parity-legal. Both branches are neutral UKS r2SCAN-3c, 18 C + 18 H frozen, no reaction-coordinate restraint in the inputs. These are Fe-free pre-existing-vacancy models, not evidence for creating a vacancy on initially pristine graphene or for competition with coordinated Fe.

V0 m3 is lower than the tested m1 by **10.807040521 kcal/mol**; it is the lowest of these tested branches, not a proof of the universal vacancy ground state. Its final S²=2.385059 differs from ideal triplet 2; retain that qualification. The final doublet adduct is in `V1_m2_restart`, whose output cleanly converges: E=−2194.326068866138 Ha, S²=0.876800, C20–N71=1.392089 Å; N71–N72=1.229932 and N72–N73=1.134259 Å preserve intact N3. Association against V0(m3)+N3(doublet) is **−61.332159414 kcal/mol**. This is another existing intact-N3 covalent counterexample, specifically at a vacancy.

The local `V1_m4` directory currently contains an input but no output/endpoint. This is **not missing execution**: the original archived output, input, endpoint and trajectory were recovered under

`MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1386_mech_loop_s1_defect_capture_V1_m4/`.

Use `output/xj_f0063dc4ad_orca.out`, `input/xj_a59dce3ea3_orca.inp`, `geometry/xj_435002d9a4_orca.xyz` and `geometry/xj_238e32b1c8_orca_trj.xyz`. Archive source pointers identify the original xj paths and hashes. Final output E=**−2194.570587964181 Ha** (line 101774), S²=3.812499; the older summary’s −2194.570120 Ha was not the final energy. The final geometry has N71–C20/C30/C31=1.419055/1.411405/1.419627 Å, N71–N72=3.424535 Å, and N72–N73=1.094833 Å: a three-carbon-coordinated vacancy N plus detached N2 geometry. Composition remains C53H18N3, so N2 is already in this endpoint; adding a further N2 energy would double-count it. Association against V0(m3)+N3(doublet) is **−214.770210025 kcal/mol**. Quartet and doublet products differ by −153.438050611 kcal/mol but are structurally different endpoints, not a vertical spin splitting.

The 63 stored quartet trajectory frames move from Nα–Nβ=1.240000 Å and single C–N=1.45 Å to the three-coordinate N plus separated N2 endpoint. This confirms loss during optimization from that initialized geometry. It does **not** establish a barrierless entrance from separated fragments, a minimum free-energy path, intersystem-crossing probability, or finite-temperature kinetics. Optimization frames are not dynamical time steps. The original threshold “N2-loss barrier ≤25 kcal/mol” cannot be numerically certified from spontaneous optimizer descent alone.

Reuse/reopen: retain vacancy capture and the two different spin-branch outcomes as finite-model observations and possible site-limited sinks. Do not close the chemistry universally or promote it automatically to the dominant reversible product. Dominance requires actual defect capacity and precursor access; reversible restoration needs a chemically balanced thermal exit. Removing substitutional N leaves a vacancy unless a carbon source and repair process are supplied. Raman recovery alone neither quantifies N removal nor determines that exit. No thermal exit barrier, vacancy concentration or Fe competition was computed in this audit.

## Exact numerical receipts

`check.py` parses original outputs/inputs, counts atoms/electrons/frozen elements, verifies multiplicity parity, recomputes endpoint distances, energy differences and quartet trajectory changes. `observations.json` retains exact absolute paths, full-file SHA256, output line numbers, input charge/multiplicity lines, geometry first-atom lines and all trajectory frame line offsets. To locate atom i in an XYZ frame, use `geometry_atom_first_line + i` (zero-based i). No path-only claim substitutes for the executed numerical checks.

Representative output sources:
- `/home/sun07ao/grephene/mech_loop/a3_gn3_triad/c54_fast/T5_14/orca.out`: energy line 45081; HURRAY lines [41572]; normal termination lines [45286].
- `/home/sun07ao/grephene/mech_loop/a3_gn3_triad/c54_fast/T5_12/orca.out`: energy line 79973; HURRAY lines []; normal termination lines [].
- `/home/sun07ao/grephene/mech_loop/a3_gn3_triad/c54_fast/T0a/orca.out`: energy line 19174; HURRAY lines [15891]; normal termination lines [19379].
- `/home/sun07ao/grephene/mech_loop/a3_gn3_triad/T0b/orca.out`: energy line 2592; HURRAY lines [1899]; normal termination lines [2797].
- `/home/sun07ao/grephene/mech_loop/s1_defect_capture/V0_m1/orca.out`: energy line 17270; HURRAY lines [12621]; normal termination lines [17475].
- `/home/sun07ao/grephene/mech_loop/s1_defect_capture/V0_m3/orca.out`: energy line 17263; HURRAY lines [12616]; normal termination lines [17468].
- `/home/sun07ao/grephene/mech_loop/s1_defect_capture/V1_m2_restart/orca.out`: energy line 22104; HURRAY lines [17283]; normal termination lines [22309].
- `/home/sun07ao/grephene/MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1386_mech_loop_s1_defect_capture_V1_m4/output/xj_f0063dc4ad_orca.out`: energy line 101774; HURRAY lines [96927]; normal termination lines [101979].

The two original attempts are numerically recoverable. Their main remaining gaps are scientific scope and missing prospective tests, not absence of their decisive raw files. No authoritative Retro state was modified.
