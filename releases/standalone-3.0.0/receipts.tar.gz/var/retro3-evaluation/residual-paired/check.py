from pathlib import Path
import re,math,json,hashlib,collections
R=Path('/home/sun07ao/grephene');W=Path(__file__).resolve().parent;S={}
def read(p):
 b=p.read_bytes();S[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b.decode(errors='replace')
def xyz(p,last=False):
 t=read(p);ls=t.splitlines();frames=[];k=0
 while k<len(ls):
  if not ls[k].strip():k+=1;continue
  n=int(ls[k]);x=[l.split() for l in ls[k+2:k+2+n]];frames.append((x,k+3));k+=n+2
 return frames[-1],len(frames)
def calc(name,base,files=None):
 fs=files or ['orca.inp','orca.out','orca.xyz'];p=[base/f for f in fs];it=read(p[0]);ot=read(p[1]);ls=ot.splitlines();m=re.search(r'\*\s*xyz(?:file)?\s+(-?\d+)\s+(\d+)',it);q,mult=map(int,m.groups());(x,xline),nf=xyz(p[2]);d=lambda i,j:math.dist(list(map(float,x[i][1:4])),list(map(float,x[j][1:4])))
 hits=lambda pat:[{'line':i,'text':l} for i,l in enumerate(ls,1) if pat in l]
 e=hits('FINAL SINGLE POINT ENERGY')[-1];s2=hits('Expectation value of <S**2>');fr=[int(v) for v in re.findall(r'\{\s*C\s+(\d+)\s+C\s*\}',it)];counts=dict(collections.Counter(a[0] for a in x));elect=sum({'C':6,'H':1,'N':7}[a[0]] for a in x)-q
 row={'id':name,'input':str(p[0]),'output':str(p[1]),'geometry':str(p[2]),'geometry_atom_first_line':xline,'frames':nf,'composition':counts,'atoms':len(x),'charge':q,'multiplicity':mult,'electrons':elect,'electron_spin_parity_legal':(elect-(mult-1))%2==0,'frozen_atoms':len(fr),'frozen_composition':dict(collections.Counter(x[i][0] for i in fr)),'energy_Ha':float(e['text'].split()[-1]),'energy_line':e['line'],'convergence':hits('HURRAY'),'normal_termination':hits('ORCA TERMINATED NORMALLY'),'S2':s2[-1:] ,'method_input_line1':it.splitlines()[0],'wavefunction_type':hits('Hartree-Fock type')[-1:],'input_charge_mult_line':it[:m.start()].count('\n')+1}
 if name.startswith('T5'):
  row['distances_A']={f'{i}-{j}':d(i,j) for i,j in [(31,72),(22 if name=='T5_14' else 20,75),(72,73),(73,74),(75,76),(76,77)]}
 if name.startswith('V1'):
  row['distances_A']={f'{i}-{j}':d(i,j) for i,j in [(20,71),(30,71),(31,71),(71,72),(72,73)]}
 return row
rows=[];b=R/'mech_loop/a3_gn3_triad'
for n in ['T5_14','T5_12','T0a']:rows.append(calc(n,b/'c54_fast'/n,['orca.inp','orca.out','orca_trj.xyz'] if n=='T5_12' else None))
rows.append(calc('N3_ref',b/'T0b'))
b=R/'mech_loop/s1_defect_capture'
for n in ['V0_m1','V0_m3','V1_m2_restart']:rows.append(calc(n,b/n))
b=R/'MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1386_mech_loop_s1_defect_capture_V1_m4'
rows.append(calc('V1_m4',b,['input/xj_a59dce3ea3_orca.inp','output/xj_f0063dc4ad_orca.out','geometry/xj_435002d9a4_orca.xyz']))
E={x['id']:x['energy_Ha'] for x in rows};K=627.5094740631
numbers={'pair_vs_flake_plus_2_N3_kcal_mol':(E['T5_14']-E['T0a']-2*E['N3_ref'])*K,'vacancy_triplet_minus_singlet_kcal_mol':(E['V0_m3']-E['V0_m1'])*K,'quartet_capture_vs_V0m3_plus_N3_kcal_mol':(E['V1_m4']-E['V0_m3']-E['N3_ref'])*K,'doublet_capture_vs_V0m3_plus_N3_kcal_mol':(E['V1_m2_restart']-E['V0_m3']-E['N3_ref'])*K,'quartet_minus_doublet_same_composition_kcal_mol':(E['V1_m4']-E['V1_m2_restart'])*K}
trj=b/'geometry/xj_238e32b1c8_orca_trj.xyz';text=read(trj);ls=text.splitlines();k=0;trace=[]
while k<len(ls):
 if not ls[k].strip():k+=1;continue
 n=int(ls[k]);x=[list(map(float,l.split()[1:4])) for l in ls[k+2:k+2+n]];trace.append({'frame':len(trace),'atom_first_line':k+3,'Na_Nb_A':math.dist(x[71],x[72]),'Nb_Ng_A':math.dist(x[72],x[73]),'Na_C_A':[math.dist(x[71],x[i]) for i in [20,30,31]]});k+=n+2
out={'audit_type':'revealed development residual discovery; frozen comparison unchanged','rows':rows,'derived':numbers,'vacancy_quartet_trajectory':trace,'source_hashes':S};(W/'observations.json').write_text(json.dumps(out,indent=2));print(json.dumps({'rows':[{k:v for k,v in x.items() if k not in ['input','output','geometry','convergence','normal_termination']} for x in rows],'derived':numbers,'quartet_trajectory_first_last':[trace[0],trace[-1]]},indent=2))
