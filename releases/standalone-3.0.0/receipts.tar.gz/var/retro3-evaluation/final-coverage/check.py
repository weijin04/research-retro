"""Read-only integrity/navigation checks for exposed coverage review; not rescoring."""
import json,hashlib,datetime
from pathlib import Path
D=Path(__file__).resolve().parent
C=Path('/home/sun07ao/retro-workspaces/grephene-retro3/current')
B=D.parent
hashes={}
def read(p):
 b=p.read_bytes();hashes[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b
s=json.loads(read(C/'SCIENTIFIC_STATE.json'));ix=json.loads(read(C/'SOURCE_INDEX.json'))['sources']
main=read(C/'MAINLINE.md').decode();nav=read(C/'NAVIGATION.md').decode()
for f in ['residual-grephene','residual-tms','residual-paired','residual-h1h2']:read(B/f/'report.md')
nodes={n['id']:n for n in s['nodes']}
selected=['obs:tms-family','claim:tms-family','route:tms-dea','obs:paired-vacancy','claim:paired-vacancy','route:paired','route:vacancy','obs:h1h2-optical','claim:h1h2-optical','obs:pair-hessian','claim:pair-scope','route:thermal']
node_evidence={k:{'revision':nodes[k]['revision'],'status':nodes[k]['data']['status'],'rationale':nodes[k]['data'].get('rationale'),'source_dependency_count':len(nodes[k]['data'].get('source_dependencies',[])),'in_mainline':k in main,'in_navigation':k in nav} for k in selected}
checks=[]
for needle in ['step6_dlpno/neutral_min/orca.out','CALC-1386_mech_loop_s1_defect_capture_V1_m4/geometry/xj_435002d9a4_orca.xyz','pt3_h1_nitride/geom.xyz','encounter_corrected/orca.out']:
 paths=[p for p in ix if needle in p];assert paths,needle
 for p in paths:
  original=read(Path(p))
  for ent in ix[p][:2]:
   b=read(C/ent['blob']);a,z=ent['byte_range'];expected=original[a:z]
   good=b==expected;assert good,(p,a,z)
   checks.append({'path':p,'blob':ent['blob'],'scope':ent['identity_scope'],'byte_range':[a,z],'matches_live_original':good})
receipt={'observed_revision':s['state_revision'],'review_type':'post-reveal development recheck; not unseen acceptance or rescoring','end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nodes':node_evidence,'captured_source_witnesses':checks,'old_completion_metadata_is_not_verdict':s['completion'],'source_hashes':hashes}
(D/'evidence.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'revision':s['state_revision'],'nodes_checked':len(selected),'source_segment_matches':len(checks),'integrity':'passed'},ensure_ascii=False))
