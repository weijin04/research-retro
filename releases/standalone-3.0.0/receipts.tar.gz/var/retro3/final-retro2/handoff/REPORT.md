# Research reconstruction

closed-qualified

Recover the declared finite two-state study, distinguish historical claims from controlled interventions, and retain non-identifiable historical execution provenance

See reconstruction.json for the frozen scope, obligations, witnesses, limited conclusions and reopening conditions.
