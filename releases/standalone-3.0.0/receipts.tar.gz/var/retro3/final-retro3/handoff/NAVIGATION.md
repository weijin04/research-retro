# Original-material navigation

Frozen state r28. Paths label historical sources; blob links work without the original project.

[SOURCE_INDEX.json](SOURCE_INDEX.json) maps captured original paths to portable bytes. References inside originals are historical; uncaptured references remain unavailable in this bundle.

<span id="route:transport"></span>
## route:transport — route:transport

Retain raw observation; repair event operator before testing physical rate


<span id="claim:alternative"></span>
## claim:alternative — claim:alternative

claim:alternative


<span id="claim:rate"></span>
## claim:rate — claim:rate

No physical rate bound from a transition-disabled implementation


<span id="obs:independent"></span>
## obs:independent — obs:independent

independent usable observation

- [/sandbox/unfamiliar-project/mixed.md (lines 2–2)](store/blobs/c3befaabe83c187de03712c9450e1ea38c59e5f6eebc7433a15ab0b6d226100a)

<span id="obs:zero"></span>
## obs:zero — obs:zero

obs:zero

- [/sandbox/unfamiliar-project/mixed.md (lines 2–2)](store/blobs/c3befaabe83c187de03712c9450e1ea38c59e5f6eebc7433a15ab0b6d226100a)

<span id="assumption:operator"></span>
## assumption:operator — assumption:operator

Original operator has no transition; the zero-count observation cannot bound the physical rate

