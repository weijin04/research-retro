#!/usr/bin/env python3
"""Read-only reconstruction; writes only beside this script. No chemistry jobs."""
import re, json, math, hashlib
from pathlib import Path
from collections import Counter
ROOT=Path('/home/sun07ao/grephene')
DEST=Path(__file__).resolve().parent
ARCH=ROOT/'MECHANISM_FIELD_AUDIT_20260907/01_INVENTORY/RAW_CACHE/xj/home/sun07ao/grephene/r4/r4p_charge_gate'
CB=ROOT/'mech_loop/entry_competition_20260911/cage_branch'
HA_KCAL=627.5094740631
HA_EV=27.211386245988
sources={}
def read(p):
    p=Path(p); b=p.read_bytes()
    sources[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    return b.decode()
def last(text,pattern):
    matches=list(re.finditer(pattern,text,re.M)); assert matches,pattern
    m=matches[-1]
    return float(m.group(1)),text[:m.start()].count('\n')+1
def xyz(p):
    lines=read(p).splitlines(); n=int(lines[0]); rows=[x.split() for x in lines[2:2+n]]
    return [(x[0],list(map(float,x[1:4]))) for x in rows]
cp=[]
for p in sorted(ARCH.glob('g[1-4]_*/g*.out')):
    s=read(p); W,lw=last(s,r'^ ENERGY\| Total FORCE_EVAL.*?([-\d.]+)\s*$')
    ct='_ct_' in p.stem
    vals={}
    for key,label in [('target','Target value of constraint'),('population','Current value of constraint'),('strength','Strength of constraint')]:
        if ct:
            v,l=last(s,rf'^\s*{label}\s*:\s*([-\d.]+)');vals[key]=v; vals[key+'_line']=l
    penalty=vals['strength']*(vals['population']-vals['target']) if ct else 0
    components=[]
    for label in ['Overlap energy of the core charge distribution','Self energy of the core charge distribution','Core Hamiltonian energy','Hartree energy','Exchange-correlation energy','Dispersion energy']:
        v,l=last(s,rf'^\s*{label}:\s*([-\d.]+)');components.append({'label':label,'value':v,'line':l})
    E=sum(x['value'] for x in components)
    assert abs(W-E-penalty)<1e-8,(p,W,E,penalty)
    row={'id':p.stem,'path':str(p),'W_Eh':W,'W_line':lw,'constraint_term_Eh':penalty,'constraint_term_kcal_mol':penalty*HA_KCAL,'E_KS_at_biased_density_Eh':E,'energy_components':components,'component_identity_error_Eh':W-E-penalty,'normal_end':'PROGRAM ENDED AT' in s,**vals}
    if ct: row['fragment_net_charge_e']=93-vals['population']
    cp.append(row)
assert len(cp)==12,len(cp)
byid={r['id']:r for r in cp}
for r in cp:
    g,typ,mult=r['id'].split('_'); base=byid[f'g1_{typ}_{mult}']; neu=byid[g+'_neu_m6']
    for k in ['W_Eh','E_KS_at_biased_density_Eh']:
        r[k+'_relative_g1_kcal_mol']=(r[k]-base[k])*HA_KCAL
        if typ=='ct':r[k+'_gap_to_neutral_eV']=(r[k]-neu[k])*HA_EV
g1inp=ROOT/'mech_loop/r4p_charge_gate/g1_ct_m4/g1_ct_m4.inp'
inp=read(g1inp); x=xyz(g1inp.parent/'geom.xyz')
fragment=Counter(a for a,_ in x[88:106]); total=Counter(a for a,_ in x)
assert sum({'C':4,'H':1,'N':5,'O':6,'Fe':16}[a] for a,_ in x[88:106])==93
g1={'input':str(g1inp),'geometry':str(g1inp.parent/'geom.xyz'),'atom_count':len(x),'composition':dict(total),'fragment_composition':dict(fragment),'NN_A':math.dist(x[103][1],x[104][1]),'total_charge':0,'multiplicity':4,'constraint_outer_max_scf':1,'constraint_outer_eps_scf':1e99,'intended_fragment_population':94,'actual_kind':'fixed external Becke population bias; target population not optimized','single_point':True,'geometric_optimization':False}
f0=CB.parent/'fe_arm/F0_pcontact_m6/orca.out'; f0s=read(f0)
eref,eline=last(f0s,r'^FINAL SINGLE POINT ENERGY\s+([-\d.]+)')
cage=[]
for job in sorted(CB.glob('C2_capture_*')):
    chosen=job/'RESTART/C3_free' if (job/'RESTART/C3_free/orca.out').exists() else job/'C3_free'
    out=chosen/'orca.out'; s=read(out); xin=read(chosen/'orca.inp'); X=xyz(chosen/'orca.xyz')
    assert X[72][0]=='Fe' and X[87][0]==X[88][0]==X[89][0]=='N' and X[32][0]=='C'
    d=lambda a,b:math.dist(X[a][1],X[b][1])
    e,le=last(s,r'^FINAL SINGLE POINT ENERGY\s+([-\d.]+)')
    frozen=list(map(int,re.findall(r'\{\s*C\s+(\d+)\s+C\s*\}',xin)))
    cn=d(87,32); fen=d(72,87); converged='HURRAY' in s
    neighbors=[{'N_index':n,'C_index':c,'distance_A':d(n,c)} for n in (87,88,89) for c in range(54) if d(n,c)<2.0]
    files={}
    for suffix in ['out','inp','xyz','gbw']:
        p=chosen/('orca.'+suffix); files[suffix]={'path':str(p),'exists':p.exists(),'bytes':p.stat().st_size if p.exists() else None}
        if p.exists() and suffix=='gbw':
            h=hashlib.sha256()
            with p.open('rb') as handle:
                for block in iter(lambda:handle.read(1024*1024),b''):h.update(block)
            sources[str(p)]={'sha256':h.hexdigest(),'bytes':p.stat().st_size}
    read(job/'C2_scan/orca.inp'); read(job/'run.sh'); read(job/'RESTART/run_restart.sh')
    cage.append({'id':job.name,'selected_directory':str(chosen),'source_files':files,'energy_Eh':e,'energy_line':le,'energy_relative_F0_kcal_mol':(e-eref)*HA_KCAL,'normal_termination':'ORCA TERMINATED NORMALLY' in s,'HURRAY':converged,'HURRAY_line':next((i for i,l in enumerate(s.splitlines(),1) if 'HURRAY' in l),None),'Na_C32_A':cn,'Fe_Na_A':fen,'Na_Nb_A':d(87,88),'Nb_Ng_A':d(88,89),'all_N_C_neighbors_below_2A':neighbors,'gate_pass':converged and cn<1.70 and fen>2.10,'gate_result':'no C4' if not (converged and cn<1.70 and fen>2.10) else 'C4 eligible','frozen_indices':frozen,'frozen_elements':dict(Counter(X[i][0] for i in frozen)),'multiplicity':int(re.search(r'\*\s*xyzfile\s+0\s+(\d+)',xin).group(1))})
assert len(cage)==4
for p in [CB/'make_c4.py',CB/'make_restart.py',CB/'make_c2.py',CB/'DESIGN_CAGE_20260914.md',CB/'C2_capture_m6_FeN280/RESTART/run_c3_manual.sh',ROOT/'mech_loop/r4p_charge_gate/VERDICT_R4P.md',ROOT/'mech_loop/R4I_CHARGE_GATE_DESIGN_20260723.md',ROOT/'AGENTS.md']:
    read(p)
table={'units':{'energy':'Eh unless specified','distance':'angstrom','indices':'0-based ORCA; CP2K group 89-106 is 1-based'},'constants':{'Eh_kcal_mol':HA_KCAL,'Eh_eV':HA_EV},'g1_object':g1,'r4p':cp,'cage':cage,'cage_reference':{'path':str(f0),'energy_Eh':eref,'line':eline},'c4_rule':{'selector':'Prefer RESTART/C3_free if its orca.out exists, otherwise C3_free','predicate':'HURRAY and Na87-C32 < 1.70 A and Fe72-Na87 > 2.10 A','eligible_count':sum(r['gate_pass'] for r in cage)},'source_hashes':sources}
(DEST/'table.json').write_text(json.dumps(table,indent=2)+'\n')
(DEST/'source_hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
print(json.dumps({'g1':byid['g1_ct_m4'],'g1_object':g1,'cage':cage,'all_checks':'passed'},indent=2))
