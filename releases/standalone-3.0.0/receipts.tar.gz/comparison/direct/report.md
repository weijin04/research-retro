# Direct raw-repository reconstruction

The r4p calculation is a converged **fixed-bias, non-target-population single point**, not a certified integer-charge CT diabat. Its reported total energy includes a −7.573906 kcal/mol constraint term. All four current cage C3 endpoints are converged Fe–N recombination states and fail the implemented C4 continuation gate. Neither finding establishes the experimental mechanism.

## r4p g1_ct_m4: intended and actual object

The surviving local input is `/home/sun07ao/grephene/mech_loop/r4p_charge_gate/g1_ct_m4/g1_ct_m4.inp`. It intends a neutral total system containing an electron-enriched Fe(NO3)2(MeCN)(N3) fragment and a graphene hole, multiplicity 4 (antiparallel coupling). The 106-atom geometry is C68H25FeN6O6: graphene C66H22 plus the 18-atom complex. Nα–Nβ is independently measured as 1.1900000003 Å; it is the historical S02 relaxed-anion trap geometry, not a newly optimized CT geometry. `RUN_TYPE ENERGY` means there is no CT geometry relaxation here. CP2K uses PBE-D3(BJ), DZVP-MOLOPT-SR-GTH, nonperiodic MT electrostatics in a 30×30×20 Å cell.

The Becke constraint is a **population** constraint on 1-based atoms 89–106. Their pseudopotential valence charges sum to 93; target 94 means one extra electron on the complex. `STRENGTH -0.10`, constraint `MAX_SCF 1`, `EPS_SCF 1e99` hold the multiplier fixed; the inner density SCF converges without optimizing that multiplier to the target. The archived output reports target 94.000000, actual 94.120697877879, deviation +0.120697877879 electrons, and strength −0.100000. Thus the corresponding Becke fragment net charge is −1.120697877879 e, with a compensating positive remainder in the neutral total system. Population partitions are method-dependent; this is not an oxidation-state measurement. The determinant's S² is 4.864675 versus ideal 3.750000 (output line 14483), another reason not to certify a pure spin diabat.

The completed output is **not** beside that local input. The reusable original-output archive is:

`/home/sun07ao/grephene/MECHANISM_FIELD_AUDIT_20260907/01_INVENTORY/RAW_CACHE/xj/home/sun07ao/grephene/r4/r4p_charge_gate/g1_ct_m4/g1_ct_m4.out`

Its final constraint record is at lines 14474–14477; inner/outer completion at 14440/14464–14468; the six ordinary energy components at 14447–14453; total FORCE_EVAL at 14598; program end at 15170. The local input and archived output are separate provenance objects; this reconstruction does not claim a missing archived input was recovered.

Independently summing the six output energy components and testing the constraint identity gives:

| Quantity | Value |
|---|---:|
| Reported W, Eh | −681.128305926726 |
| V(N−Ntarget), Eh | −0.0120697877879 |
| V(N−Ntarget), kcal/mol | −7.57390618684 |
| E_KS[ρ_V] = W − V(N−Ntarget), Eh | −681.116236138938 |
| Identity residual, Eh | −3.69×10⁻¹⁴ |

This subtraction removes the explicit constraint term **at the already biased density**; it does not solve the target-constrained problem or recover an unbiased ground state. The check script repeats this energy-component identity for all 12 archived r4p CP2K outputs, including neutral references, rather than relying on a historical summary.

| Derived quantity | Reported W convention | E_KS[ρ_V] convention |
|---|---:|---:|
| g1 m4 gap to neutral m6, eV | 0.549733 | 0.878169 |
| g1 m6 gap to neutral m6, eV | 0.55453 | 0.98307 |
| m4 g3−g1 rise, kcal/mol | 41.9783 | 44.0749 |
| m6 g3−g1 rise, kcal/mol | 44.7009 | 40.1215 |
| g3 m4 from g1 neutral, kcal/mol | 54.6554 | 64.3260 |

The **relative rise ordering** reverses between m4 and m6; these rises use each spin's own g1 baseline, so this is not a same-geometry absolute spin ordering claim. The historical 2.37 eV “near one-photon threshold” comes from W (54.6554 kcal/mol); subtracting the explicit term changes it to about 2.79 eV even before resolving the non-target densities. The old “CT opens before peak”, physical CT excitation gaps, quantitative lowering versus the net-anion proxy, surface parallelism/crossing or back-transfer conclusions, and threshold mechanistic inference must therefore be withdrawn or re-established with proper states and comparable energy references. The gap increasing along the sampled coordinate remains a numerical property of these particular calculations in both conventions, not a measured return rate. Cross-code/functional comparisons to an ORCA anion further cannot isolate the effect of the hole.

What remains reusable: original geometry, atom mapping, numerical convergence evidence, fixed-bias population response, archived density-run energy ledger, and the explicit convention correction. Neither convention alone establishes an integer-charge excited-state surface, CT lifetime, barrier, transition state, photochemical accessibility, or experimental pathway. No new quantum calculation was performed.

## Cage continuation and present handoff

The owning local root is `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/` (denoted CB below). The actual chain has distinct conditions:

1. C2 constrains Fe72–Nα87 at its selected cage separation and scans Nα87–C32 toward 1.50 Å. The original `C2_capture_*/run.sh` seeds C3 from the lexicographically last `orca.0*.xyz` plus matching GBW. It prints C2 success/failure, but **does not use normal termination as a hard condition** before continuing if those seed files exist. It therefore does not itself certify that the seed is a completed target endpoint.
2. C3 releases the reaction-distance constraints but retains 36 frozen boundary **atoms**. Actual inputs and XYZ elements show 18 C + 18 H, despite the historical scripts/docs saying “36 frozen edge C”. The present C3 runs use q=0, m=4 or 6, UKS r2SCAN-3c Opt TightSCF.
3. Recovery prefers current `RESTART/C3_free/orca.out` where present. `make_restart.py` lines 70–72 uses the final numbered scan point, falling back to `orca.xyz/gbw` for the single remaining constrained-optimization case. m6 FeN280 also has `RESTART/run_c3_manual.sh`, an actual special-case continuation after the last constrained optimization stalled. Do not confuse the interrupted root C3 directories with the finished restarted endpoints.
4. `make_c4.py` lines 23–27 implements the restarted-output preference. Lines 36–45 require **HURRAY AND Nα87–C32 < 1.70 Å AND Fe72–Nα87 > 2.10 Å**. Equality fails. This is the operational continuation rule, not the earlier section-1 qualitative condition of a low capture peak and Fe–N >2.5. If eligible, lines 46–51 build a nine-point Nα87–Nβ88 relaxed stretch from the current value to 2.30 Å, same multiplicity and boundary constraints, free Fe–N and C–N distances; generation does not launch it. Section 5.1 of `DESIGN_CAGE_20260914.md` (lines 447–465) describes subsequent peak/end wB97X checks and conditional interpretation.

The independent script reads each selected output/input/XYZ, checks mapped elements, recomputes distances, searches **all three azide N against all 54 graphene C** below 2.0 Å, extracts final energies and applies the literal predicate. All four have HURRAY and normal termination; none has an N–C neighbor below 2.0 Å.

| C2 parent | Nα–C32 Å | Fe–Nα Å | Nα–Nβ / Nβ–Nγ Å | E relative F0 kcal/mol | C4 |
|---|---:|---:|---:|---:|---|
| C2_capture_m4_FeN250 | 3.271450 | 1.868167 | 1.211960 / 1.143018 | +16.27050 | no |
| C2_capture_m4_FeN310 | 3.259512 | 1.868121 | 1.211974 / 1.142932 | +16.23377 | no |
| C2_capture_m6_FeN250 | 3.208128 | 1.882814 | 1.198666 / 1.146516 | −0.49558 | no |
| C2_capture_m6_FeN280 | 3.233273 | 1.895170 | 1.201494 / 1.146443 | +0.05409 | no |

The exact reusable endpoint directories are:

- `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m4_FeN250/RESTART/C3_free/`
- `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m4_FeN310/RESTART/C3_free/`
- `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m6_FeN250/RESTART/C3_free/`
- `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m6_FeN280/RESTART/C3_free/`

Each contains verified-existing `orca.xyz`, `orca.gbw`, `orca.inp`, `orca.out`. XYZ atom positions are at atom-index+3 lines; thus C32 line 35, Fe72 line 75, N87/88/89 lines 90/91/92. In the table's order, HURRAY/final-energy output lines are 152185/158289, 185975/192078, 112742/118626, 125013/130980. Absolute energies and the independently read F0 reference `/home/sun07ao/grephene/mech_loop/entry_competition_20260911/fe_arm/F0_pcontact_m6/orca.out` are in `table.json` with its exact energy line. Reusing a GBW still depends on a compatible runtime; existence and hash do not establish portability.

**Current bounded decision:** no C4 seed passes the implemented gate. For the four tested starting points and this neutral finite cluster, releasing reaction constraints returns an intact azide coordinated to Fe, not a retained graphene–azide capture basin or N₂-loss product. This supports downgrading this tested cage-continuation route. It does not prove all cage chemistry impossible, certify a recombination rate or a barrier-free path, or exclude solvent/ligand replenishment, another conformer/spin state, excited-state dynamics, escape, or another radical. In particular, this check did not independently replay the historical wB97X trajectory claims or prove the sixfold-multiplicity endpoints geometrically identical to F0; near-zero energy is insufficient for that stronger claim. Direction changes or new jobs are outside this read-only task.

## Reproduction and completion boundary

Run `rtk proxy python3 /home/sun07ao/retro-workspaces/comparison/direct/check.py`. It writes only this arm's `table.json` and `source_hashes.json`. Source content hashes include numerical outputs, geometry/input files, reference energy output, continuation code, historical intent/design, and current endpoint GBWs. No scientific source was modified; no supplied builder was executed because builders write the scientific tree.

The required two reconstructions and raw numerical checks are complete within the declared budget. Remaining unverified scope is explicit above: original remote inputs no longer present in the archive, wavefunction physical state certification, complete trajectories/hybrid checks, kinetics and experimental applicability. This is one small development comparison. Shell-count and wall-clock receipts are in `receipt.json`; token usage is unavailable.
