from pathlib import Path
import re,json,math,hashlib
R=Path('/home/sun07ao/grephene'); W=Path(__file__).resolve().parent
sources={}
def read(p):
 b=p.read_bytes();sources[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b.decode()
def last(t,pat):
 m=list(re.finditer(pat,t,re.M))[-1];return float(m.group(1)),t[:m.start()].count('\n')+1
out=R/'MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1675_r4_r4p_charge_gate_g1_ct_m4/output/xj_1942e9bcbe_g1_ct_m4.out'
t=read(out); E,el=last(t,r'^ ENERGY\| Total FORCE_EVAL.*?(-?\d+\.\d+)\s*$'); pop,pl=last(t,r'^  Current value of constraint\s*:\s*([\d.]+)');strength,sl=last(t,r'^  Strength of constraint\s*:\s*(-?[\d.]+)');target,tl=last(t,r'^  Target value of constraint\s*:\s*([\d.]+)')
terms=[]
for label in ['Overlap energy of the core charge distribution','Self energy of the core charge distribution','Core Hamiltonian energy','Hartree energy','Exchange-correlation energy','Dispersion energy']:
 v,l=last(t,r'^  '+re.escape(label)+r':\s*(-?[\d.]+)');terms.append({'label':label,'Ha':v,'line':l})
bare=sum(x['Ha'] for x in terms);penalty=strength*(pop-target)
assert abs(E-bare-penalty)<1e-9
inp=R/'mech_loop/r4p_charge_gate/g1_ct_m4/g1_ct_m4.inp';read(inp)
geom=R/'mech_loop/r4p_charge_gate/g1_ct_m4/geom.xyz';read(geom)
r4={'id':'g1_ct_m4','source':str(out),'reported_energy_Ha':E,'reported_line':el,'component_sum_Ha':bare,'constraint_term_Ha':penalty,'reported_minus_components_eV':(E-bare)*27.211386245988,'reported_minus_components_kcal_mol':(E-bare)*627.5094740631,'population':pop,'population_line':pl,'target':target,'strength':strength,'terms':terms,'meaning':'Total FORCE_EVAL includes lambda*(population-target); subtracting this term changes energy convention at the same fixed-strength density, not into a target-converged state.'}
b=R/'mech_loop/entry_competition_20260911/cage_branch';rows=[]
read(b/'make_c4.py');read(b/'make_c2.py');read(b/'make_restart.py')
for job in sorted(b.glob('C2_capture_*')):
 c3=job/'RESTART/C3_free';c3=c3 if (c3/'orca.out').exists() else job/'C3_free'
 t=read(c3/'orca.out');X=read(c3/'orca.xyz').splitlines();n=int(X[0]); X=[l.split() for l in X[2:2+n]];assert n==90 and X[72][0]=='Fe' and X[87][0]==X[88][0]=='N' and X[32][0]=='C'
 d=lambda a,b:math.dist([float(v) for v in X[a][1:4]],[float(v) for v in X[b][1:4]])
 nc,fe,nn=d(87,32),d(72,87),d(87,88);txt=read(c3/'orca.inp'); mult=int(re.search(r'xyzfile\s+0\s+(\d+)',txt).group(1));h='HURRAY' in t
 rows.append({'id':job.name,'selected_C3':str(c3),'xyz':str(c3/'orca.xyz'),'out':str(c3/'orca.out'),'input':str(c3/'orca.inp'),'gbw':str(c3/'orca.gbw'),'gbw_exists':(c3/'orca.gbw').exists(),'multiplicity':mult,'HURRAY':h,'HURRAY_lines':[i for i,l in enumerate(t.splitlines(),1) if 'HURRAY' in l],'normal_termination':'ORCA TERMINATED NORMALLY' in t,'Na87_C32_A':nc,'Fe72_Na87_A':fe,'Na87_Nb88_A':nn,'Na_C_neighbors_under_2A':sorted((d(87,c),c) for c in range(54) if d(87,c)<2),'C4_gate_pass':h and nc<1.70 and fe>2.10,'frozen_C_count':len(re.findall(r'\{\s*C\s+\d+\s+C\s*\}',txt))})
result={'r4p':r4,'cage':rows,'constants':{'Ha_eV':27.211386245988,'Ha_kcal_mol':627.5094740631}}
(W/'table.json').write_text(json.dumps(result,indent=2));(W/'source_hashes.json').write_text(json.dumps(sources,indent=2));print(json.dumps(result,indent=2))
