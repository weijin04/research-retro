# Current-state handoff: two historical attempts

This bounded reconstruction used original local inputs, archived CP2K output, actual continuation code and four stored ORCA end-state geometries. No scientific job or source-writing project script was run. The retrospective context declares prior historical exposure: it is not a blind review.

## r4p g1_ct_m4

The intended question was whether explicitly compensating a reduced complex with a graphene hole made charge transfer accessible before the extrusion peak, unlike the net-anion proxy. The intended state is total charge 0, multiplicity 4, complex atoms 89–106 with valence population 94 against neutral-fragment 93. The 106-atom geometry is inherited from an anion-relaxed ORCA structure (XYZ comment energy −4649.596889461814 Ha); the CP2K ENERGY run is a single point, not a reoptimization of that intended CT state. Input: `mech_loop/r4p_charge_gate/g1_ct_m4/g1_ct_m4.inp:11–38`; geometry: same directory `geom.xyz:1–108`. CP2K PBE-D3BJ/DZVP, nonperiodic 30×30×20 Å cell.

Actual constraint: fixed strength −0.10, target 94, achieved 94.120697877879. CDFT MAX_SCF=1, EPS_SCF=1e99 allows the printed outer-loop convergence without meeting the target. This is a finite fixed-strength biased-density state, distinct from an exact integer-transfer diabat. Ordinary electronic SCF convergence survives this distinction.

The archived original is `MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1675_r4_r4p_charge_gate_g1_ct_m4/output/xj_1942e9bcbe_g1_ct_m4.out`. Its final energy-component lines 14448–14453 sum to −681.116236138938 Ha; FORCE_EVAL at line 14598 is −681.128305926726 Ha. Lines 14474–14477 give the target, population, residual and strength. The independently executed check establishes

`reported − component_sum = λ(N−target) = −0.0120697877879 Ha = −0.328435657405 eV = −7.57390618686 kcal/mol`.

Subtracting the constraint term raises the energy by that amount. It changes energy convention at the same density; it does not turn this density into a target-converged solution. The historical collector (`collect.sh:11`) selected FORCE_EVAL. Thus the historical 0.550 eV gap is not automatically a physical exact-target excitation energy. Nor can one repair the whole four-geometry curve with this single constant: each population residual may differ.

Retain: original calculation and geometry provenance, SCF convergence, fixed-strength population and energy observations, reproducible numerical arithmetic, and comparisons explicitly labeled with the same model and convention. Revise/quarantine physical CT accessibility, photon-budget thresholds, barrier reductions or route exclusion, recombination timing and downstream Marcus/reorganization/rate interpretations until consistent state identities and energy conventions are established. Removing the bias term alone does not establish physical validity; one SP cannot certify a barrier or lifetime. The historical verdict already acknowledges residual and cross-method limits (`VERDICT_R4P.md:51–58`), but those warnings do not resolve this energy-convention difference. Next action: define and validate matched diabats and energy semantics at the required geometries before reusing the profile or rate descendants.

## C2 capture → C3 release → C4 gate

`make_c2.py:8–29` contracts Na87–C32 while keeping Fe72–Na87 fixed, then releases both reaction constraints in C3; 36 sheet edge C atoms remain frozen. Indexing is zero-based. The original chain takes the lexically last `orca.0*.xyz` if the matching GBW exists. Its normal-termination check prints status but does not guard continuation, so “C3 ran” does not prove a completed C2 grid. `make_restart.py:26–79` resumes remaining scan points, uses a constrained Opt when one point remains, and permits final `orca.xyz`/GBW as seed. Existing `RESTART/C3_free/orca.out` takes precedence over original C3 (`make_c4.py:23–27`), even before checking its convergence.

Exact C4 predicate (`make_c4.py:35–44`): output contains HURRAY AND Na87–C32 <1.70 Å AND Fe72–Na87 >2.10 Å. Equality fails. Passing would build a nine-point Na87–Nb88 scan to 2.30 Å with original multiplicity, 36 frozen edge C and no Fe–Na or Na–C restraint (`make_c4.py:45–49`). It builds but does not launch.

| Current job | Na–C32 / Å | Fe–Na / Å | Na–Nb / Å | HURRAY | C4 |
|---|---:|---:|---:|---|---|
| C2_capture_m4_FeN250 | 3.271450 | 1.868167 | 1.211960 | yes | fail both distances |
| C2_capture_m4_FeN310 | 3.259512 | 1.868121 | 1.211974 | yes | fail both distances |
| C2_capture_m6_FeN250 | 3.208128 | 1.882814 | 1.198666 | yes | fail both distances |
| C2_capture_m6_FeN280 | 3.233273 | 1.895170 | 1.201494 | yes | fail both distances |

All selected endpoints are `mech_loop/entry_competition_20260911/cage_branch/<job>/RESTART/C3_free/` beneath `/home/sun07ao/grephene`. Reusable files are `orca.xyz`, `orca.inp`, `orca.out`, and existing `orca.gbw`; full exact paths and convergence line numbers are in `table.json`. Geometry atom rows for zero-based C32/Fe72/Na87/Nb88 are XYZ lines 35/75/90/91. No Na carbon neighbor is within 2 Å in any endpoint. All four pass numerical optimization convergence but lose the designated C–N capture and return to short Fe–N contact. Therefore none licenses C4 by the registered rule. This is a failed continuation from four specific seeds under this model and boundary, not a no-go theorem for all cage chemistry, other attack sites, multiplicities or dynamics. Do not manufacture C4 from these failed seeds; any renewed route needs an independently justified capture state that survives release.

## Reproduction and limitations

Run `python3 check.py` from this output directory; it reads originals, recomputes the energy identity and four gate results, and writes only local `table.json`/`source_hashes.json`. Those hashes identify bytes used; workflow context also captures selected byte spans and exact source locators. No assumption that a directory listing alone verifies a number. The GBWs were checked for existence only, not content or restart usability. These outputs are not four independent physical events or statistical kinetics data.

Scope is the two requested attempts, not complete Grephene reconstruction. No live remote state was queried, no full four-point CP2K curve was independently recomputed, and no frequency/dynamics/transition-state conclusion was derived. Review was self-review, not cold handoff. A metadata census enumerated the broad source project but is not scientific reading coverage. The historical document was exposed before sealing; this limitation is retained in the workflow packet. Context creation initially exceeded the default 1 MB capture budget; bounded exact byte segments were then used, with original full-file hashes separately retained.
