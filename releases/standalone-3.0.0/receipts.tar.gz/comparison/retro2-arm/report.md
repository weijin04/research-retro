# Current-state handoff: two historical attempts

The r4p calculation is reusable as a **fixed-potential biased-density single point**, not an achieved target-charge CT diabat. All four current cage C3 end states **fail the implemented continuation gate**, so these results supply no eligible C4 seed. These conclusions were recomputed from original archived energy output and current stored coordinates; no scientific jobs or source-writing scripts were run.

## r4p g1_ct_m4

Intended question: explicit graphene-hole/complex-electron accessibility before N–N extrusion, with a same-Hamiltonian neutral baseline. The 106-atom object is C66H22 graphene plus Fe(NO3)2(MeCN)(N3), total q=0, multiplicity 4; it is not the net-anionic precursor. The geometry is the S02 relaxed-anion trap (N103–N104 = 1.1900000003 Å, zero-based), evaluated as a CP2K ENERGY single point with PBE-D3BJ/DZVP-MOLOPT-SR-GTH, nonperiodic MT and 30×30×20 Å cell. Geometry provenance does not make it an equilibrium neutral or CT structure.

Input `mech_loop/r4p_charge_gate/g1_ct_m4/g1_ct_m4.inp:12–38` sets complex atoms 89–106 (one-based), neutral valence count 93 and TARGET 94; V=−0.10, CDFT MAX_SCF=1 and EPS_SCF=1e99 hold the potential rather than solve for a target-reaching multiplier. Original output reports population **94.120697877879**, residual **+0.120697877879 electron**. The numerical SCF convergence/normal completion is real; its CDFT convergence label does not establish the physical target constraint.

The original remote-location receipt is `MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1675_r4_r4p_charge_gate_g1_ct_m4/SOURCE_POINTERS.tsv:2`; the surviving raw original copy is that directory's `output/xj_1942e9bcbe_g1_ct_m4.out`. Its SHA256 is `1942e9bcbe8c8a2aba2918f6e2990f07e16197e1d9a931659adf237d751cfbb7`, agreeing with the historical receipt. Do not assume the original remote path still exists.

`check.py` independently sums the six final energy components (raw output lines 14448–14453) and checks the relation against population/strength (14474–14477) and FORCE_EVAL (14598):

`W = E_KS[rho_V] + V(N−N_target)`

| Quantity | Recomputed value |
|---|---:|
| W / Eh | −681.128305926726 |
| E_KS[rho_V] / Eh | −681.116236138938 |
| W − E_KS / Eh | −0.01206978778790 |
| W − E_KS / eV | −0.3284356574 |
| W − E_KS / kcal/mol | −7.573906187 |

Removing the explicit term still leaves the energy of the biased density; it does not recover a target-converged diabat, unbiased relaxed state or optical excitation. W values may describe the specified biased calculation. E_KS values may describe that same density with the bias energy removed. Comparisons must preserve Hamiltonian, geometry, q/m, density definition and reference convention. Raw coordinates, input, densities/populations and computational provenance remain reusable.

Historical `VERDICT_R4P.md` calls the result “CT opens before peak” and uses ~0.550 eV g1 gaps and a ~2.37 eV threshold. Those physical accessibility, quantitative CT-gap, profile/ranking, pure hole-compensation, lifetime/back-transfer and photon-budget interpretations require revision: W is not the same observable as a physical diabat energy; the constraint is unfulfilled; sampled geometries are not optimized diabatic minima; static energies alone do not establish optical population or dynamics. The original design's failure rule says unmet population must not enter the trend table, while the historical verdict accepts similarity to another fixed-strength template. Preserve that changed acceptance rule as history, not proof of a converged constraint. This arm did not recompute other r4p points or the neutral reference, so does not supply a newly certified full profile/gap.

## Cage continuation

`cage_branch/C2_capture_m4_FeN310/run.sh:14–22` chooses the lexicographically last `orca.0*.xyz` and matching `.gbw` for C3. Normal C2 termination is printed but is not a blocking gate in that launcher. C3 releases reactive Fe–N and N–C constraints while retaining 36 frozen boundary atoms (18 edge C plus 18 H, as indicated by indices 0–71); “free” does not mean every atom moves. The current endpoints are restart results.

The executable rule in `cage_branch/make_c4.py:23–49` selects `RESTART/C3_free` when its `orca.out` exists, otherwise `C3_free`. It requires HURRAY, zero-based Na87–C32 < 1.70 Å **and** Fe72–Na87 > 2.10 Å. Equality fails. If passed, C4 would scan Na87–Nb88 from its current distance to 2.30 Å in nine points, keeping the boundary and multiplicity, with Fe–N and Na–C unrestrained. This differs from treating any finished C3 or the older prose's >2.5 Å basin criterion as sufficient authorization.

| C2 branch | Na–C32 / Å | Fe–Na / Å | Na–Nb / Å | C4 gate |
|---|---:|---:|---:|---|
| m4_FeN250 | 3.271450 | 1.868167 | 1.211960 | fail |
| m4_FeN310 | 3.259512 | 1.868121 | 1.211974 | fail |
| m6_FeN250 | 3.208128 | 1.882814 | 1.198666 | fail |
| m6_FeN280 | 3.233273 | 1.895170 | 1.201494 | fail |

All four outputs contain HURRAY and normal termination; none has a Na–C neighbor under 2 Å. Distances use final `orca.xyz`, not starting geometry or rounded prose. Exact reusable directories, each containing `orca.xyz`, `orca.gbw`, `orca.inp`, `orca.out`, `start.xyz` and `start.gbw`:

```
/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m4_FeN250/RESTART/C3_free
/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m4_FeN310/RESTART/C3_free
/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m6_FeN250/RESTART/C3_free
/home/sun07ao/grephene/mech_loop/entry_competition_20260911/cage_branch/C2_capture_m6_FeN280/RESTART/C3_free
```

XYZ lines 35/75/90/91 contain C32/Fe72/Na87/Nb88. HURRAY lines are respectively 152185, 185975, 112742, 125013; per-source hashes and energies are in `table.json`. Wavefunctions are present but were not parsed or authenticated as restart-compatible by this check.

The sampled q0 r2SCAN-3c m4/m6 boundary-constrained optimizations return to Fe-associated azide with loss of captured C–N. They do not establish a persistent captured basin for these starts, and do not meet the actual C4 condition. They do not measure competing rates/yields, exclude every basin, or refute excited-state cage chemistry. Reopening requires evidence of a genuinely retained C–N endpoint under a specified revised model/condition, not relabeling these converged endpoints as products.

## Delivery and evidence boundary

`check.py`, `table.json`, `source_hashes.json` and `receipt.json` provide the repeatable postprocessor, numeric results, exact paths and run accounting. Retro 2.0's manual was printed; separate metadata-only init, selected reads, reconstruction, audit open/check/submit and export organized the work. The compatible audit executes a host-authored read-only postprocessor, not an OS-sandboxed scientific run. Its packet pins input and gate source; the postprocessor reads and hashes additional raw originals independently. This is a selected two-attempt audit, not a full-corpus snapshot/reconstruction, blinded discovery or a complete physical validation. Repository historical interpretations were visible, then checked against raw outputs; no other arm, personal scientific memory or new Retro3 material was used.
