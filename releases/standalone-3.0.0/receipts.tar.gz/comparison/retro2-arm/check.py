import pathlib, re, math, json, hashlib, collections, sys
W=pathlib.Path(__file__).resolve().parent
P=pathlib.Path('/home/sun07ao/grephene')
CB=P/'mech_loop/entry_competition_20260911/cage_branch'
A=P/'MECHANISM_FIELD_AUDIT_20260907/02_CALCULATIONS/CALC-1675_r4_r4p_charge_gate_g1_ct_m4'
sources={}
def read(p):
    b=p.read_bytes(); sources[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    return b.decode()
def xyz(p):
    t=read(p).splitlines(); n=int(t[0]); a=[(s.split()[0],list(map(float,s.split()[1:4]))) for s in t[2:n+2]]
    assert len(a)==n
    return a
out=read(A/'output/xj_1942e9bcbe_g1_ct_m4.out')
def last(pattern): return float(re.findall(pattern,out)[-1])
N=last(r'Current value of constraint\s*:\s*([-\d.]+)')
T=last(r'Target value of constraint\s*:\s*([-\d.]+)')
V=last(r'Strength of constraint\s*:\s*([-\d.]+)')
E=last(r'ENERGY\| Total FORCE_EVAL.*?([-\d.]+)\s*\n')
terms={label:last(re.escape(label)+r':\s*([-\d.]+)') for label in ['Overlap energy of the core charge distribution','Self energy of the core charge distribution','Core Hamiltonian energy','Hartree energy','Exchange-correlation energy','Dispersion energy']}
eks=sum(terms.values()); bias=V*(N-T)
assert abs(E-eks-bias)<1e-8
x=xyz(P/'mech_loop/r4p_charge_gate/g1_ct_m4/geom.xyz')
read(P/'mech_loop/r4p_charge_gate/g1_ct_m4/g1_ct_m4.inp')
read(A/'SOURCE_POINTERS.tsv')
read(P/'mech_loop/R4I_CHARGE_GATE_DESIGN_20260723.md')
read(P/'mech_loop/r4p_charge_gate/VERDICT_R4P.md')
r={'case':'r4p_g1_ct_m4','atom_count':len(x),'composition':dict(collections.Counter(a[0] for a in x)),'charge':0,'multiplicity':4,'fragment_one_based':[89,106],'target_population':T,'actual_population':N,'population_error':N-T,'strength':V,'W_hartree':E,'E_KS_density_V_hartree':eks,'W_minus_EKS_hartree':bias,'W_minus_EKS_eV':bias*27.211386245988,'W_minus_EKS_kcal_mol':bias*627.5094740631,'energy_sum_terms':terms,'NN_angstrom':math.dist(x[103][1],x[104][1]),'raw_output':str(A/'output/xj_1942e9bcbe_g1_ct_m4.out'),'status':'biased_density_not_target_converged_diabat'}
rows=[]
for job in sorted(CB.glob('C2_capture_*')):
    d=job/'RESTART/C3_free'
    if not (d/'orca.out').exists(): d=job/'C3_free'
    if not (d/'orca.xyz').exists(): continue
    a=xyz(d/'orca.xyz'); o=read(d/'orca.out'); inp=read(d/'orca.inp')
    assert [a[i][0] for i in [72,87,88,32]]==['Fe','N','N','C']
    dist=lambda i,j:math.dist(a[i][1],a[j][1])
    nc,fe,nn=dist(87,32),dist(72,87),dist(87,88)
    rows.append({'case':job.name,'c3_path':str(d),'atom_count':len(a),'charge':0,'multiplicity':int(re.search(r'xyzfile\s+0\s+(\d+)',inp).group(1)),'hurray':'HURRAY' in o,'normal_termination':'ORCA TERMINATED NORMALLY' in o,'CN_angstrom':nc,'FeN_angstrom':fe,'NN_angstrom':nn,'carbon_neighbors_under_2A':[(i,dist(87,i)) for i in range(54) if dist(87,i)<2],'frozen_atoms':list(map(int,re.findall(r'\{\s*C\s+(\d+)\s+C\s*\}',inp))),'C4_gate_pass':'HURRAY' in o and nc<1.70 and fe>2.10,'last_energy_hartree':float(re.findall(r'FINAL SINGLE POINT ENERGY\s+([-\d.]+)',o)[-1]),'hurray_line':next(i for i,l in enumerate(o.splitlines(),1) if 'HURRAY' in l),'xyz_atom_lines':{'Fe':75,'Na':90,'Nb':91,'C32':35}})
    read(job/'run.sh')
    if (job/'RESTART/run_restart.sh').exists():read(job/'RESTART/run_restart.sh')
read(CB/'make_c4.py');read(CB/'DESIGN_CAGE_20260914.md')
result={'r4p':r,'cage':rows,'source_hashes':sources,'units':{'distance':'angstrom','energy':'hartree unless labelled'}}
(W/'table.json').write_text(json.dumps(result,indent=2))
(W/'source_hashes.json').write_text(json.dumps(sources,indent=2))
if len(sys.argv)>1:
    packet=json.loads(pathlib.Path(sys.argv[1]).read_text())
    print(json.dumps({'packet_hash':packet['content_hash'],'results':result}))
else: print(json.dumps({'r4p':r,'cage':rows},indent=2))
