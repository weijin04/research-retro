# Public working protocol

Use `retro -w W workflow ...`; the function equivalent is `retro_workflow` with
`workspace`, `action` and the same arguments. JSON files may be replaced by `-`
to read stdin. The state store is authoritative; never edit it directly.

## Small complete construction

Start on a real source directory:

```sh
retro init /path/to/project --workspace /path/to/retro-workspaces/project --metadata-only --capture-max-bytes 33554432
retro -w /path/to/retro-workspaces/project workflow start --goal "Restore the tested routes and current evidence"
retro -w /path/to/retro-workspaces/project workflow discover --limit 24
```

Author a context after locating the relevant originals. `start/end` are inclusive
1-based lines. `bytes: [start,end]` optionally captures a byte segment, then lines
refer to that segment. Byte identity is segment-only; it does not prove identity
of the rest of the file. `key` names a material for `nodes[].sources`.

```json
{"question":"Does this output close the transport route?",
 "prior_exposure":"Have read the project summary; initial review is not blind",
 "materials":[
   {"key":"model","path":"model.md","start":1,"end":8,"role":"definition"},
   {"key":"raw","path":"result.tsv","start":1,"end":4,"role":"evidence"},
   {"key":"old","path":"model.md","start":10,"end":14,"role":"history"}],
 "focus":[]}
```

```sh
retro -w W workflow context --input context.json
retro -w W workflow seal context:RETURNED_ID --input initial.json
retro -w W workflow reveal context:RETURNED_ID
```

`initial.json` contains a completed `analysis` and nonempty `alternatives` array.
It should state what the evidence actually distinguishes and the missing test,
not merely announce a method. Preserve it when the historical account changes
your interpretation. Copy the issued `input_hash` into the submission:

```json
{"context":"context:RETURNED_ID","input_hash":"ISSUED_HASH",
 "reviewer":"host-name/model-or-person","analysis":"Completed derivation with numeric substitutions and applicable assumptions.",
 "alternatives":["No transport","Finite positive rate with zero observed events"],
 "nodes":[
   {"id":"obs:zero","type":"observation","title":"Zero recorded events",
    "statement":"The captured output reports N=0 for this run.",
    "scope":{"run":"run-A","observable":"detected event count"},
    "status":"observed","rationale":"Counted events in the original rows; termination alone was not used.","sources":["raw"]},
   {"id":"route:transport","type":"route","title":"Transport route remains open",
    "statement":"This zero count does not establish an impossible mechanism.",
    "scope":{"object":"sample-A","test":"run-A"},"status":"open",
    "rationale":"Finite rates also yield zero events; operator and effective sampling require verification.",
    "sources":["model","old"],"requires":["obs:zero"],"links":["obs:zero"],
    "details":{"historical_interpretation":"Route was closed in the old summary",
      "next_discriminating_action":"Check operator reachability, detection and effective T before computing a rate bound",
      "reopen_condition":"An event-capable test with defined exposure"}}]}
```

```sh
retro -w W workflow apply --input understanding.json
retro -w W workflow publish
retro -w W workflow show route:transport
retro -w W export
```

Node types: `question`, `object`, `attempt`, `observation`, `assumption`, `claim`,
`route`, `turn`, `gap`, `asset`. Required: `id,type,title,statement,scope,status,rationale`.
Optional: `sources,requires,supports,counters,links,details`.

All node types share these status values: `observed`, `conditional`, `supported`,
`open`, `untested`, `paused`, `rejected`, `withdrawn`, `superseded`,
`implementation_failed`. `active` is not a status; an active research question
is `open`, a retained conditional asset is `conditional`. Status is the host's
scoped judgment, while current support/freshness is computed separately.

- `sources` selects material keys in this context; these become exact locators.
- `requires` pins indispensable contextual dependencies. Revision or loss of
  these nodes requires reassessment, including through transitive dependencies.
- `supports` and `counters` are arrays of arrays of IDs, outer OR / inner AND.
  Only observed original witnesses or explicit conditional assumptions start
  affirmative support. Cycles cannot certify themselves; conflicts block use.
  Revision pins keep an edited premise from silently supporting an old argument.
- `links` is navigation, not an inferred scientific support relationship.
- `details` carries actual object distinctions, plan/actual/result, observable
  semantics, derivations, historical motives, limitations, reopen conditions,
  prospective checks or auditable optional semantic judgments. No universal
  domain ontology is required.

For dependencies on existing nodes, add their IDs to `context.focus` before
reading/sealing. The packet freezes their revisions. New nodes may reference
other new nodes in the same apply. To revise a node, include it in focus and
submit its complete new content; omitted fields are deliberately removed.
History is retained. Reversible split/merge uses superseded old objects and
replacement links, followed by revised membership/arguments/routes.

## Discovery and revision

`workflow discover --query TEXT` filters the captured metadata ledger by path.
`--offset` pages; `--limit` bounds output. Use original text search in addition.
`workflow refresh` refreshes captured bytes and the census, not scientific
judgments. `workflow scope --input FILE` records a changed goal with current
session `revision`, new `goal`, `reason` and optional includes/excludes/relations.

`workflow impact NODE --query ALIASES` finds declared dependents and lexical
candidates for undeclared dependencies. This is a host search aid, not exhaustive
semantic inference. `workflow view` returns the whole current scientific map;
`workflow show NODE` returns that node, original spans and history revisions.

## Assess actual work

After drafting a handoff, run the cold tasks and residual checks. Submit:

```json
{"reviewer":"reviewer identity",
 "coverage":{"sufficient":true,"basis":"Which important questions/routes/periods/source families were recovered and how the distribution was checked"},
 "residual_review":{"samples":[{"path":"unlinked/file","finding":"Actual result of reading","consequence":"Changes made or why none"}],"material_omissions":[]},
 "handoff":{"passed":true,"tasks":["Comparable table actually recovered","Original value actually checked","Next test designed"],"receipt":"Path/hash of the retained reader work and grading"},
 "limitations":["Precisely uninspected domains or scientific uncertainty"],
 "scientific_problem":"open: distinguish remaining compatible mechanisms",
 "continuation":"ready for the scoped next test; no job submitted"}
```

The tool records these as host reports. It checks freshness and declared support;
it cannot grade scientific correctness or prove that the host really ran a task.
Retain the actual outputs. Use `sufficient:false` or `passed:false` when warranted.
After `workflow assess --input FILE`, publish and export. A later node/scope
revision makes the assessment stale. New assessment records preserve failures.

Portable outputs include `index.html`, `MAINLINE.md`, `SCIENTIFIC_STATE.json`,
`NAVIGATION.md`, `SOURCE_INDEX.json`, source blobs and revision history. Open them without a server.
The source index maps historical absolute paths to captured bytes and byte ranges;
relative references inside originals resolve against those original parent paths.
Unlisted referenced assets are not in the bundle. An index of thousands of runs
does not mean their original data have all been captured or reviewed.
`retro inspect BUNDLE` verifies integrity; `retro verify-handoff` retains 2.0
query/replay support. A frozen old bundle is historical, not live-current state.
