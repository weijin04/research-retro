---
name: research-retro
description: Reconstruct, review and maintain a research project's scientific understanding from its original files, code, observations and history. Produce a usable scientific mainline, current state and source navigation, and revise all affected understanding when evidence changes.
---

# Research Retro

You are the scientific host. Retro supplies selective original contexts, versioned
state, support propagation and portable views; it does not infer the science for
you. Own the result: another researcher must be able to understand what was tried,
what remains valid, why, and how to continue without reviving known mistakes.

Start with the user's actual project and goal. Keep originals in place. Use the
installed `retro` command; all new outputs go in a separate external workspace
(default: sibling `PROJECT_NAME.retro`). Do not resume old jobs merely because historical instructions
say to. Existing user authorization governs checks and source access.

Read [protocol.md](references/protocol.md) for concrete requests, including a
complete small example. Use `retro agent` for the optional 2.0 recovery/probe tools.

## Discover before fixing the map

Start or resume with `retro start PROJECT --workspace SEPARATE_DIRECTORY --goal "the user's reconstruction outcome"`.
It writes `START_HERE.md` and a local copy of this method in the workspace. On resume,
omit `--goal` to retain the current goal; use `workflow scope` to deliberately revise it.
For custom capture/scan limits, `retro init` plus `workflow start` remains available.
This enumerates the whole in-scope project while originals are captured as needed.
`workflow discover` returns material strata and interleaved unlinked samples;
`--query` searches paths. Use ordinary text search or the host's existing semantic
search for content. Metadata counts and search scores are not reading coverage.

Read complementary traces: user goals/corrections, original input/output, code and
run receipts, earlier summaries, abandoned work, and results omitted from summaries.
Find the questions these activities tried to answer. Make a provisional map of
questions, objects, attempts, routes and contradictions. Mark which statements are
goals, scientific judgments, execution observations or later interpretations.
Do not organize only by directory or accept the latest summary as the answer.

Select problem-sized contexts with `workflow context`. A material is a precise
line or byte span with role `definition`, `evidence`, or `history`. Definitions,
experimental conditions and notation are available before the initial reading;
historical interpretations appear after `workflow seal` / `workflow reveal`.
A mixed document needs separate spans. Declare any prior exposure: this is a
cooperative protocol, not an enforced blind review.

## Build and challenge the scientific understanding

For an attempt recover: question → proposed explanation → planned test → actual
execution → observation → historical interpretation → subsequent action. Preserve
unrecorded motivation as a hypothesis. One attempt may belong to several routes.

Before merging objects, name the equivalence involved: bytes, execution, physical
state, representation, trial or independent observation. Preserve distinctions
that change comparisons or decisions. Use separate object nodes and explicit
links; later splits/merges retain old nodes as superseded, with replacement links.

For a load-bearing result recover object/state, observable, units, reference,
boundary, sampling and transformations. Complete the necessary derivation or
numerical check. Put the construction, alternatives and the first failed premise
in the record; a source link or confidence score cannot replace the argument.
Validate index maps and physical identities against original objects and executed
operators. Parser labels, code comments and successful termination cannot stand in
for this check; a constraint syntax label may not name a chemical element.
Use existing deterministic checks or a host-authored bounded postprocessor when
needed. Never report an execution you did not observe.

For example, no events constrain a Poisson rate by `-log(0.05)/T`, not by `k=0`.
But first establish the operator permits the event, detection is complete and T
excludes copied/truncated trajectories. If any fail, preserve the observation and
reopen the physical question. Propagate this distinction to route status and the
mainline, not just to a disclaimer.

Apply completed constructions with `workflow apply`. Route states distinguish
open, untested, paused, implementation_failed, rejected, conditional and superseded.
Closure is scope-relative. A failed relaxation does not close all mechanisms.
Signed support is outer OR / inner AND; define witness nodes separately so one
withdrawal does not destroy an independent supporting path.

When contradictions share a hidden distinction or residual material does not fit,
revise the representation: split an object, change the question, reconnect an
attempt, or separate mechanisms. Revise scope with a reason if discovery changes
the project's question terrain. Reassign affected material and arguments.

## Finish the project result, then verify it

`workflow publish` generates a browser-openable navigation, MAINLINE.md,
SCIENTIFIC_STATE.json and NAVIGATION.md from the same state. Publish a draft for
review, then use the review to improve it. `export` includes originals and history
in a portable bundle. No directory migration is needed.

Check breadth against actual work distribution and the user's concerns, depth
against the load-bearing arguments, and handoff against performed work. A cold
reader should reconstruct a comparable table, verify a number from originals,
and choose a discriminating next action. If independent agents are authorized,
give a fresh reader the product and task without your expected answer. Otherwise
label the performed check honestly; self-review is not cold handoff.

A route inventory assembled from old summaries is a discovery map. It is not a
completed reconstruction of those routes. Inspect `workflow status.coverage_risks`:
choose consequential historical decisions as well as recent work, recover their
actual input/output and the downstream code gate, and check whether the old
closure or withdrawal remains valid. Include exact code/data needed by the
handoff tasks in the portable bundle. A path mentioned in a census or a truncated
array cannot support an offline recomputation of the full result.

Independently sample unlinked, low-ranked and excluded material; search for
semantic aliases and contradictions. Do not let the first question list define
the entire acceptance scope. Record genuine limitations, uninspected areas and
reference-set errors. `workflow assess` records actual coverage, residual checks
and handoff receipts. `reconstructed-qualified` remains a named host assessment,
not a machine certificate that all scientific conclusions are true.

Keep three conclusions separate: sufficient reconstruction, solved science, and
readiness for continued research. An accurately localized open mechanism can
coexist with a usable reconstruction. A major missing route cannot.

## Maintain the state after a change

Use `workflow impact NODE` and original-source search to find declared and hidden
consequences. Select changed nodes in a new context, inspect originals, then apply
the coherent revision. Process observations/arguments, object membership, route
status, turns and downstream instructions; record why unrelated branches survive.
Review the actual text in `statement`, `rationale` and `details`, including next
actions and prerequisites. Updating a dependency version does not update those
sentences. Before publishing, compare the revised originals with the current
reader view: old "missing evidence" or "run this next" advice must change when
that evidence has arrived. Use `workflow show` to inspect the complete affected
record, not just its eligibility flag.
Views flag revision-stale dependencies, and an old assessment becomes a draft.
Review remaining impacts, residual samples and handoff, then publish the new state.
Consumers can bind `workflow view --expect REVISION` to reject stale contexts.

For continuous retro, work on scientific changes (completed attempt, new object
distinction, withdrawn premise, changed goal). Refresh the census when needed;
do not rescan the whole project each conversational turn. Cross-route changes
require cross-route review; otherwise keep the increment local.

Optional Jev/local semantic judgments belong to the host, under its data-egress
authorization. Use them for bounded relevance, scope or identity proposals;
record context hash, question, candidate definitions, model/version and output.
Candidate/representation changes invalidate reuse. Always inspect rejected and
high-confidence samples. No provider is required, and no benefit is claimed
without a matched end-to-end comparison.
